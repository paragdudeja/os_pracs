<?php
$temp = explode(' ', "This is a sentence with seven words");
print_r($temp);

$arr=Array("A","E","I","O","U");
$st='A E-I-O-U';
print_r(implode('-',$arr));
print_r(explode(' ',$st));
?>