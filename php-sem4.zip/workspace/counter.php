<!DOCTYPE html>
<html>
    <body>
        <form action="#" method="post">
            <input type="submit" name="inc" value="inc" />
            <input type="submit" name="dec" value="dec"/>
            <br>
        </form>
        
        <?php
            static $num=0;
            if(isset($_POST["inc"])){
                $num++;
                echo "$num";
            }
            if(isset($_POST["dec"])){
                $num--;
                echo "$num";
            }
        ?>
    </body>
</html>