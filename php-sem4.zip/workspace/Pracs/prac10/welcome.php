<?php
	session_start();
?>

<!DOCTYPE html>
<html>
    <body>
        <?php
            $name=$_SESSION['uname'];
            echo "Welcome $name";
        ?>
    </body>
</html>
