<?php
	session_start();
?>
<!DOCTYPE html>
<html>
    <body>
        <form action='#' method='post'>
            Email ID:
            <input type="text" name="email"/>
            <br>
            Password:
            <input type="text" name="password"/>
            <br>
            <input type="submit" value="Login" name='login'/>
        </form>
        <?php
            if(isset($_POST['login'])){
                $email=$_POST['email'];
                $password=$_POST['password'];
                
                $host='localhost';
        		$user='root';
        		$pass='';
        		$dbname='sscbs';
        		
        		$conn=new mysqli($host,$user,$pass,$dbname);
        		$sql="select name from student where email='$email' and password='$password';";
        
        		$result=$conn->query($sql);
        		if($result->num_rows>0){
        		    $row = $result->fetch_assoc();
        		    $_SESSION['uname']=$row['name'];
        		    header('Location: welcome.php');
        		}
        		else
        			echo 'error!! invalid credentials';
        	}
        ?>
    </body>
</html>
