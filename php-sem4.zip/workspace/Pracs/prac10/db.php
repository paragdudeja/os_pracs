<!DOCTYPE html>
<html>
    <body>
        STUDENT PORTAL <br>
        <form action='#' method='post'>
            <input type="submit" value="LOGIN" name="login"/>
            <input type="submit" value="SIGN UP" name="signup"/>
        </form>
        <?php
            if(isset($_POST['signup'])){
                header("Location: signup.php");
            }
            if(isset($_POST['login'])){
                header("Location: login.php");
            }
        ?>
    </body>
</html>
