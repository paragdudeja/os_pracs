<html>
<body>
<h1>Register</h1>

<form action='#' method='post'>
Name:
<input type='text' name='sname'><br>

Contact:
<input type='text' name='contact'><br>

Email :
<input type='text' name='email'><br>

Password:
<input type='password' name='password'><br>

<input type='submit' value='Register' name='register'>
<br>

<?php

	if(isset($_POST['register'])){
		$name=$_POST['sname'];
		$contact=$_POST['contact'];
		$email=$_POST['email'];
		$password=$_POST['password'];

		$host='localhost';
		$user='root';
		$pass='';
		$dbname='sscbs';
		
		$conn=new mysqli($host,$user,$pass,$dbname);
		$sql="insert into student(name,contact,email,password) values('$name','$contact','$email','$password');";

		$result=$conn->query($sql);
		if($result){
			echo 'enrolled successfully';
		}
		else
			echo 'error!! student already enrolled';
	}

?>


</body>
<html>
