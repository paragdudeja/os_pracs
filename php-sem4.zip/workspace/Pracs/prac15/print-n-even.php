<!DOCTYPE html>
<html>
    <body>
        <form action="#" method="post">
            Enter number: <input type="number" name="str"/><br>
            <input type="submit" name="submit" value="Print first n even numbers"/>
        </form>
        <?php
            $num=$_POST['str'];
            
            if(isset($_POST["submit"])){
                if($num<1){
                    echo "Please enter a number grater than 1!!";
                }
                else
                    for($i=1;$i<=$num;$i++){
                        echo $i*2," ";
                    }
            }
        ?>
    </body>
</html>