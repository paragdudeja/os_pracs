<!DOCTYPE html>
<html>
    <body>
        <form action="#" method="post">
            Enter text: <input type="text" name="str"/><br>
            <input type="submit" name="submit" value="Check palindrome"/>
        </form>
        <?php
            $text=$_POST['str'];
            
            if(isset($_POST["submit"])){
                $text_new=str_replace(" ","",$text);
                if($text_new==strrev($text_new))
                    echo "$text is a palindrome";
                else
                    echo "$text is not a palindrome";
            }
        ?>
    </body>
</html>