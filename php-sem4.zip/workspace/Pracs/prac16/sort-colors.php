<!DOCTYPE html>
<html>
    <body>
        
    <?php
        $colors=array("white","green","red");
        for($i=0;$i<count($colors);$i++){
            echo " ".$colors[$i];
            if($i!=count($colors)-1)
                echo ", ";
        }
        echo "<br>";
        sort($colors);
        echo "<ul>";
        for( $i=0; $i<count($colors) ; $i++ ){
            echo "<li>".$colors[$i]."</li>";
        }
        echo "</ul>";
    ?>
    </body>
</html>