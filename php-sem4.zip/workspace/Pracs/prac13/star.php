<?php
    for($i=1;$i<=5;$i++){
        for($j=1;$j<$i;$i++){
            echo "* ";
        }
        echo "<br>";
    }
?>