<?php

$a=$_POST['num1'];
$b=$_POST['num2'];
$c=$_POST['num3'];



echo "first no. is $a <br>";
echo "second no. is $b <br>";
echo "third no. is $c <br><br>";

if($a>$b&&$a>$c)
    echo "$a";

if($b>$a&&$b>$c)
    echo "$b";
    
if($c>$b&&$c>$a)
    echo "$c";
    
echo " is the largest";
?>