<?php
        $op=$_POST['lgn'];

        switch($op)
        {
            case 'op1': echo "Hello";
                            break;
            case 'op2': echo "Hola";
                            break;
            case 'op3': echo "Hallo";
                            break;
            case 'op4': echo "Bonjour";
        }
    ?>