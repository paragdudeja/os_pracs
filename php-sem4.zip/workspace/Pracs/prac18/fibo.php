<!DOCTYPE html>
<html>
    <body>
        <form action="#" method="post">
            <h1>Fibonacci Series</h1>
            Enter the no. of terms : <input type="number" name="num"/> <br>
            <input type="submit" name="submit" value="Submit"/>
            <br>
        </form>
        <?php
            $num=$_POST["num"];
            
            function fibo($n){
                if($n==1)
                    return 0;
                if($n==2)
                    return 1;
                return fibo($n-1)+fibo($n-2);
            }
            
            if(isset($_POST["submit"])){
                if($num<1)
                    echo "Enter a number greater than zero!!";
                else{
                    
                    echo "Fibonacci  series: ";
                    for($i=1;$i<=$num;$i++){
                        echo fibo($i)."";
                        if($i<$num)
                            echo ",";
                        echo " ";
                    }
                }
            }
        ?>
    </body>
</html>