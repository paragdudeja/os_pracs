<html>
    <body>
        <h2>Check whether the number you input is prime</h2>
        <form action='#' method='get'>
            Enter a number: 
            <input type='number' name='num'>
            <br><br>
            <input type='submit' name='submit' value'check prime'><br><br>
        </form>
        
        <?php
            $num=$_GET['num'];
            
            $flag=true;
            for($i=2;$i<$num/2;$i++){
                if($num%$i==0){
                    $flag=false;
                    break;
                }
            }
            if(isset($_GET['submit']))
            if($flag==true)
                echo "$num is prime";
            else
                echo "$num is not prime";
        ?>
    </body>
</html>