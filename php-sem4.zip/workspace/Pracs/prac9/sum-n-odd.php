<!DOCTYPE html>
<html>
    <body>
        <form action="#" method="post">
            Enter number : <input type="number" name="num"/><br>
            <input type="submit" name="submit" value="Sum of first N odd numbers"/>
        </form>
        <?php
            $num=$_POST['num'];
            
            if(isset($_POST["submit"])){
                if($num<1)
                    echo "Enter a number greater than 1!!";
                else
                    echo "Sun of first $num odd numbers is: ",$num*$num;
            }
        ?>
    </body>
</html>