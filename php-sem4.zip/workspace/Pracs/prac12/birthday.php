<?php
        $b=$_POST['bd'];
        $list=explode('-',$b);
        $ubd=mktime(0,0,0,$list[1],$list[2],$list[0]);

        $t=time();

        $diff=($ubd-$t);
        $days=(int)($diff/86400);
        
        echo "Number of days left->".$days;
    ?>