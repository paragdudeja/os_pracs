<!DOCTYPE html>
<html>
    <body>
        <form action="#" method="post">
            Enter text: <input type="text" name="str"/><br>
            <input type="submit" name="submit" value="Remove whitespaces"/>
        </form>
        <?php
            $text=$_POST['str'];
            
            if(isset($_POST["submit"])){
                $text=str_replace(" ","",$text);
                echo "$text";
            }
        ?>
    </body>
</html>