<html>
    <body>
        <form action='#' method='post'>
            Enter a number:
            <input type='number' name='num'>
            <br><br>
            <input type='submit' name='sub' value='calulate factorial'>
        </form>
        
        <?php
            $n=$_POST['num'];
            function factorial($x){
                $result=1;
                for($i=$x;$i>=1;$i--)
                    $result=$result*$i;
                return $result;
            }
            if(isset($_POST['sub']))
                echo "Factorial of $n is ". factorial($n);
     
        ?>
    </body>
</html>