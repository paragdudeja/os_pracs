<!DOCTYPE html>
<html>
    <body>
        <form action='#' method='post'>
            Enter text: 
            <input type="text" name="str"/>
            <input type="submit" value="Check lowercase" name='submit'/>
        </form>
        
        <?php
            $str=$_POST['str'];
            if(isset($_POST['submit'])){
                if(preg_match("/[A-Z]/",$str)){
                    echo "Not lowercase :(";
                }
                else{
                    echo "All lowercase :)";
                }
            }
        ?>
    </body>
</html>