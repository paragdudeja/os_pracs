<html>
    <body>
        <form action='#' method='post'>
            Enter a string:
            <input type="text" name="str"/> <br>
            <input type="submit" name='submit' value="Submit"/>
        </form>
        
        <?php
            $data=$_POST['str'];
            if(isset($_POST['submit'])){
                $pos=strpos($data,"the");
                echo substr_replace($data, "That" ,$pos,strlen("the"));
            }
        ?>
    </body>
</html>