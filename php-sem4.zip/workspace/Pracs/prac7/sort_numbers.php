<!DOCTYPE html>
<html>
    <body>
        <form action="#" method="post">
            Enter a number: <input type="number" name="num"/>
            <br>
            <input type="submit" name="add" value="Add this number"/>
            <br>
            <input type="submit" name="sort" value="Sort these numbers"/>
            <br><br>
        </form>
        <?php
            static $numbers=array();
            static $i=0;
            if(isset($_POST["add"])){
                $num=$_POST["num"];
                //echo "$num";
                //global $numbers,$i;
                $numbers[$i++]=$num;
                echo "Numbers are: ";
                echo json_encode($numbers);
                //echo "$numbers";
                /*for($j=0;$j<count($numbers);$j++){
                    echo count($numbers) .", $i";
                    if($j!=0)
                        echo " , ";
                    echo " ".$numbers[$j];*/
                //}
                echo "<br>";
            }
            
            if(isset($_POST["sort"])){
                if(count($numbers)!=0){
                    echo "No numbers to sort!!";
                }
                else{
                    sort($numbers);
                    echo "Sorted numbers are: ";
                    for($j=0;$j<count($numbers);$j++){
                        echo $numbers[$j].", ";
                    }
                }
            }
            
        ?>
    </body>
</html>