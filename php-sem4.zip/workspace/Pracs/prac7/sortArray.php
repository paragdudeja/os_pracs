<?php
        $i=0;
        foreach($_POST['num'] as $v)
        {
            $array[$i]=$v;
            $i++;
        }

        sort($array);

        $i=0;
        while($i!=5)
        {
            echo $array[$i]." ";
            ++$i;
        }
    ?>