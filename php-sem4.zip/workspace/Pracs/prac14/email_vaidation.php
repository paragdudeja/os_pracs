<!DOCTYPE html>
<html>
    <body>
        <form action='#' method='post'>
            Enter email id: 
            <input type="text" name="email"/>
            <input type="submit" value="Check lowercase" name='submit'/>
        </form>
        
        <?php
            $email=$_POST['email'];
            if(isset($_POST['submit'])){
                if(!preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix",$email)){
                    echo "Not a valid email id :(";
                }
                else{
                    echo "Valid email id :)";
                }
            }
        ?>
    </body>
</html>