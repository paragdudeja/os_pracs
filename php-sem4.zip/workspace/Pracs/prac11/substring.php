<!DOCTYPE html>
<html>
<body>
    <form action='#' method='post'>
        Enter a string:
        <input type="text" name="str1" placeholder="Enter text"/>
        <br>
        Enter substring to search:
        <input type="text" name="str2" placeholder="Enter text"/>
        <br>
        <input type="submit" value="Check for substring" name='submit'/>
        <br>
    </form>
    
    <?php
        $str=$_POST['str1'];
        $sub=$_POST['str2'];
        if(isset($_POST['submit'])){
            if(strpos($str,$sub)!==FALSE){
                echo 'Substring present in string';
            }
            else{
                echo 'Substring not present in string'; 
            }
        }
        
    ?>
    
</body>

</html>

