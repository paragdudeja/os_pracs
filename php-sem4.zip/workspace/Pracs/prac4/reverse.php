<html>
    <body>
        <h1>Reverse a string</h1>
        <form action="#" method='post'>
            Enter a string: <br>
            <input type='text' name='str'>
            <input type='submit' name='submit' value='Reverse string'>
        </form>
        <?php
            $text=$_POST['str'];
            if(isset($_POST['submit']))
                echo "Reversed string: ".strrev($text);
        ?>
    </body>
</html>