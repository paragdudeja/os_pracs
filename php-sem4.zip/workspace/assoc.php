<?php

/*$nums[]=1;
$nums[]=2;
$nums[]=3;*/
//$num=7;
$nums=array(7,2,3);
$roll=array('17511'=>'Parag','17510'=>'DEEPAK','17507'=>'Shanu');
//echo (is_array($nums)) ? "Is an array" : "Is not an array";

while(list($nos,$nom)=each($nums)){
    echo "$nos:$nom <br>";
}

list($a, $b) = array('Alice', 'Bob');
echo "a=$a b=$b";

foreach($roll as $no=>$name){
    echo "<br>$no: $name";
}

/*asort($roll, SORT_NUMERIC);
print_r($roll);
ksort($roll, SORT_STRING);
print_r($roll);*/
//echo phpinfo();

/*for($i=0;$i<3;$i++){
    echo "$i: $nums[$i]<br>";
}*/
/*print_r($roll);
echo "<br>". $roll['17510'];*/

/*function writeMsg() {
    echo "Hello world!";
}

writeMSg();*/

?>