 <?php
echo str_replace(" ", "", "Hello world!"); // outputs Hello Dolly!
?> 