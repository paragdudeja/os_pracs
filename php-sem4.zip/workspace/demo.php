<?php
/*$number = 12345 * 67890;
echo substr($number, 3, 2);*/
/*$pi
= "3.1415927";
$radius = 5;
echo $pi * ($radius * $radius);*/
echo "This is line " . __LINE__ . " of file " . __FILE__;
//    echo longdate(time());
    echo "<br>Hello World <br>";
    echo "b: [" . true . "]<br>";
    $a = 1000;
$b = 1000;
echo ($a xor $b);
//if ($a === $b) echo "1";
    print("Good<br>");
    echo("yup<br>");
    //echo $_SERVER['SERVER_NAME'];
    $num=7;
    $num ? print "TRUE" : print "FALSE";
    echo <<<_END
<br>Debugging is twice as hard as writing the code in the first place. \n
Therefore, if you write the code as cleverly as possible, you are,
by definition, not smart enough to debug it.
- $author. <br>
_END;
echo <<<SQL
select * $num
  from $tablename
 where id in [$order_ids_list]
   and product_name = "widgets"
SQL;
?>