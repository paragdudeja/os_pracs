<html>
<body>
<h1>Enrollment form</h1>

<form action='#' method='get'>
Name:
<input type='text' name='sname'><br>

Course: 
<select name="course">
  <option value="bsc">BSc</option>
  <option value="bms">BMS</option>
  <option value="bfia">BFIA</option>
</select><br>

Roll No. :
<input type='number' name='rollno'><br>

<input type='submit' value='Submit' name='submit'>
<input type='submit' value='Display' name='display'>

<?php

	if(isset($_GET['submit'])){
		$name=$_GET['sname'];
		$course=$_GET['course'];
		$rollno=$_GET['rollno'];

		$host='localhost';
		$user='root';
		$pass='';
		$dbname='enrollment';
		
		$conn=new mysqli($host,$user,$pass,$dbname);
		$sql="insert into student(name,course,rollno) values('$name','$course','$rollno');";

		$result=$conn->query($sql);
		if($result){
			echo 'enrolled successfully';
		}
		else
			echo 'error!! student already enrolled';
	}

	if(isset($_GET['display'])){
		$host='localhost';
		$user='root';
		$pass='';
		$dbname='enrollment';
		
		$conn=new mysqli($host,$user,$pass,$dbname);
		$sql="select name,course,rollno from student ;";
		$result=$conn->query($sql);
		if($result){
			echo '<table border="1"><tr><th>Name</th><th>Course</th><th>Roll No</th></tr>';

			while($row = $result->fetch_assoc()) {
        			echo "<tr><td>".$row['name']."</td><td>".$row['course']."</td><td>".$row['rollno']."</td></tr>";
    			}

		}
		else
			echo 'error!!';
	}

?>


</body>
<html>