#include<iostream>
#include<cstring>
#include<cstdlib>
using namespace std;

int main(){
    int count=0;
    char str[30];
    char cl;
    cout<<"Enter the IPv4 address: "; cin>>str;

    for(int i=0;str[i]!='\0';i++){
        if(str[i]=='.')
            count++;
    }
    int num=atoi(str);
    //cout<<"\nBase: "<<num<<endl;
    if(num>=0&&num<=127)
        cl='A';
    if(num>=128&&num<=191)
        cl='B';
    if(num>=192&&num<=223)
        cl='C';
    if(num>=224&&num<=239)
        cl='D';
    if(num>=240&&num<=255)
        cl='E';
    if(num<0||num>255)
        cl='\0';
    if(cl!='\0'&&count==3)
        cout<<"\nClass: "<<cl<<endl;
    else
        cout<<"\nInvalid IPv4 address!!\n";
}