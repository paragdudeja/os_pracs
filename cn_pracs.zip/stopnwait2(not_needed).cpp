#include<iostream>
using namespace std;

void sender(int i){
    cout<<"\nSequence no.: "<<i+1<<"       ";
    cout<<"Frame "<<(i%2)<<" sent: ";
}

void receiver(int i){
    int k;
    if(i%2==0)
        k=1;
    else
        k=0;
//    for(int j=0;j<400000000;j++);
    cout<<"\nACK"<<k<<" received\n";
//    for(int j=0;j<400000000;j++);
}

int main(){
    int no_of_frames,i=0;
    cout<<"Enter no. of frames: "; cin>>no_of_frames;
    while(i<no_of_frames){
        sender(i);
        receiver(i);
        i++;
    }
    return 0;
}