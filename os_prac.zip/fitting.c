#include<stdio.h>

int main(){
    int flag;
    int i,j;
    int no_of_holes,no_of_processes;
    int hole_size[30],process_size[30];
    int best[30],worst[30];
    printf("Enter the no. of holes : "); scanf("%d",&no_of_holes);
    printf("Enter the size of %d holes: \n",no_of_holes);
    for(i=0;i<no_of_holes;i++){
        scanf("%d",&hole_size[i]);
        best[i]=hole_size[i];
    }

    for(i=0;i<no_of_holes-1;i++){
        for(j=0;j<no_of_holes-i-1;j++){
            if(best[j]>best[j+1]){
                int temp=best[j];
                best[j]=best[j+1];
                best[j+1]=temp;
            }
        }
    }

    for(j=0;j<no_of_holes;j++){
        worst[j]=best[no_of_holes-j-1];
    }

    printf("Enter the no. of processes : "); scanf("%d",&no_of_processes);
    printf("Enter the size of %d processes: \n",no_of_processes);
    for(i=0;i<no_of_processes;i++){
        scanf("%d",&process_size[i]);
    }

    printf("\nFirst fit: \n");
    for(i=0;i<no_of_processes;i++){
        flag=0;
        for(j=0;j<no_of_holes;j++){
            if(process_size[i]<=hole_size[j]){
                printf("%d \t%d\n",process_size[i],hole_size[j]);
                hole_size[j]-=process_size[i];
                flag=1;
                break;
            }
        }
        if(!flag){
                printf("%d : No hole available for this process :(\n",process_size[i]);
            }
    }

    /*printf("\nDescending order: ");
    for(i=0;i<no_of_holes;i++){
        printf("%d ",worst[i]);
    }
    printf("\n");*/

    printf("\n\nBest fit: \n");
    for(i=0;i<no_of_processes;i++){
        flag=0;
        for(j=0;j<no_of_holes;j++){
            if(process_size[i]<=best[j]){
                printf("%d \t%d\n",process_size[i],best[j]);
                best[j]-=process_size[i];
                flag=1;
                break;
            }
        }
        if(!flag){
                printf("%d : No hole available for this process :(\n",process_size[i]);
            }
    }

    printf("\n\nWorst fit: \n");
    for(i=0;i<no_of_processes;i++){
        flag=0;
        for(j=0;j<no_of_holes;j++){
            if(process_size[i]<=worst[j]){
                printf("%d \t%d\n",process_size[i],worst[j]);
                worst[j]-=process_size[i];
                flag=1;
                break;
            }
        }
        if(!flag){
                printf("%d : No hole available for this process :(\n",process_size[i]);
            }
    }

    return 0;
}