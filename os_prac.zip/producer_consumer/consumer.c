#include<stdio.h>
#include "prod_cons.h"
#include <sys/shm.h>
#include <sys/stat.h>

#define SIZE 1024

int main(){
	int flag=1;
	int key=9010;
	int shmid=shmget(key,SIZE,0666|IPC_CREAT);
	shared *m=shmat(shmid,NULL,0);
	m->in=m->out=0;
	while(flag){
		while((m->in)==(m->out));
		printf("\nData consumed from buffer: %d",m->buffer[(m->out)]); //scanf("%d",m->buffer[in]);
		(m->out)=((m->out)+1)%BUFFER_SIZE;
		printf("Consume more? (0 to stop): "); scanf("%d",&flag);
	}
	shmdt(m);
	shmctl(shmid,IPC_RMID,NULL);
}