#define BUFFER_SIZE 5

typedef struct shared{
	int buffer[BUFFER_SIZE];
	int in;
	int out;
}shared;
