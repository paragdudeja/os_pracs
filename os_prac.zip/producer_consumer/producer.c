#include<stdio.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include "prod_cons.h"

#define SIZE 1024

int main(){
	int flag=1;
	int key=9010;
	int shmid=shmget(key,SIZE,0666|IPC_CREAT);
	shared *m=shmat(shmid,NULL,0);
	m->in=m->out=0;
	while(flag){
		while((((m->in)+1)%BUFFER_SIZE)==(m->out));
		printf("Enter data to buffer: "); scanf("%d",&m->buffer[(m->in)]);
		(m->in)=((m->in)+1)%BUFFER_SIZE;
		printf("Produce more? (0 to stop)\n"); scanf("%d",&flag);
	}
	shmdt(m);
}