#include<pthread.h>
#include<unistd.h>
#include<stdio.h>

long count=0;

void *runner(void *param){
    long i=0;
    //int num=(int)param;
    for(i=0;i<2000000000;i++) count++;

}

int main(){
    int var=15;
    pthread_t tid,tid2;
    pthread_create(&tid,NULL,runner,NULL);
    pthread_join(tid,NULL);
    pthread_create(&tid2,NULL,runner,NULL);
    //pthread_join(tid,NULL);
    pthread_join(tid2,NULL);
    printf("Count: %li\n",count);
    return 0;
}