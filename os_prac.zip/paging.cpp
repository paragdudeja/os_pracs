#include<iostream>
#include<cstdlib>
using namespace std;

int fsize, msize,nf;
int ftable[500][2];

class process
{
    public:
    int pid,psize,ptable[50],n,ppage;

    void process1()
    {
        cout<<"Enter the process id "<<endl;
        cin>>pid;
        cout<<"Enter the process size"<<endl;
        cin>>psize;
    }

    void npage()
    {
        if(psize%fsize==0)
        {
            ppage=psize/fsize;}
        else
        {
            ppage=(psize/fsize)+1;
        }
        cout<<"Number of pages required by the process is : "<<ppage<<endl;
    }

    void table()
    {
    for(int i=0;i<nf;i++)
    ftable[i][0]=0;

    cout<<"\tPage Index"<<"\tFrame Number"<<endl;

    for(int i=0;i<ppage;i++)
    {
        ptable[i]=(rand()%nf);
        n=ptable[i];

        if(ftable[n][0]!=1)
        {
            ftable[n][0]=1;
            ftable[n][1]=pid;
        }

        else
        {
            while(ftable[n][0]==1)
                n++;
            ptable[i]=n;
            ftable[n][0]=1;
            ftable[n][1]=pid;
        }

        cout<<"\t"<<"P"<<i<<"\t\t"<<ptable[i]<<endl;}
    }
};

void deallocate()
{
    int p;
    cout<<"Enter the process to be deallocated :"<<endl;
    cin>>p;
    for (int x=0; x<nf; x++)
    {
        if(ftable[x][1]==p)
        {
            ftable[x][0]=0;
            ftable[x][1]=0;
        }
    }

    cout<<"Frame Number"<<"\tFrame Status"<<"\tProcess Id"<<endl;
    for(int i=0;i<nf;i++)
    {
        cout<<i<<"\t\t"<<ftable[i][0]<<"\t\t"<<ftable[i][1]<<endl;
    }
}

int main()
{
    char ch='y';
    int num,p;
    cout<<"Enter frame size (in KB)"<<endl;
    cin>>fsize;
    cout<<"Enter main memory size (in MB)"<<endl;
    cin>>msize;
    nf=(msize*1024)/fsize;
    cout<<"Enter the number of processes to be entered  : ";
    cin>>num;
    process obj[num];
    for(int k=0;k<num;k++)
    {
        obj[k].process1();
        obj[k].npage();
        obj[k].table();
    }
    deallocate();
    return 0;
}