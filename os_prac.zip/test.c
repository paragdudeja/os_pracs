#include<stdio.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <pthread.h>
int main(){
	const int SIZE=4096;
	//int *num =malloc(sizeof(int));
	// printf("Enter a number: "); scanf("%d",num);
	// printf("Entered number is: %d\n",*num );
	// printf("%li\n",sizeof(int));
	int key=12345;
	int shmid=shmget(key,SIZE,0666|IPC_CREAT);
    int *num=(int*)shmat(shmid,NULL,0);
    printf("Enter a number: "); scanf("%d",num);
    printf("Entered number is: %d",*num);
    shmdt(num);
	return 0;
}