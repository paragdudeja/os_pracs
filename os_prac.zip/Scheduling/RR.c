#include<stdio.h>
#include<stdlib.h>

typedef struct Node{
    int ID;
    int BT;
    int WT;
    int TA;
    struct Node* next;
}Node;

int time_slice=1;
float avg_wt=0,avg_ta=0;
int count=0;


Node *tail=NULL;

void addProcessToList(int id,int bt){
    Node *p=malloc(sizeof(Node));
    p->ID=id;
    p->BT=bt;
    p->WT=0;
    p->TA=0;
    count++;
    if(tail==NULL){
			tail=p;
			tail->next=p;
    }
	else{
	    p->next=tail->next;
		tail->next=p;
		tail=tail->next;
	}
}

void display(){
    if(tail!=NULL){
        Node *temp=tail->next;
        do{
            printf("P%d ",temp->ID);
            temp=temp->next;
        }while(temp!=tail->next);
    }
    else{
        printf("** No processes present in ready queue\n");
    }
}

void startExecution(){
    if(tail!=NULL){
        int flag=1;
        Node *curr=tail->next;
        Node *prev =tail;
        while(flag){
            if(curr->BT>time_slice){
                printf("P%d: running for %d bursts\n",curr->ID,time_slice);
                curr->TA+=time_slice;   
                (curr->BT)-=time_slice;
                curr=curr->next;
                prev=prev->next;
                
                /*Node *temp=curr;
                do{
                    temp->WT+=time_slice;
                    temp=temp->next;    
                }while(temp!=curr);*/

            }
            else{
                //printf("P%d: running for %d bursts\n",curr->ID,curr->BT);
                //printf("P%d terminated\nWaiting time= %d\nTurnaround time=%d\n",curr->ID,curr->WT/2,curr->WT+curr->TA);
                //Node *temp=curr;
                curr=curr->next;
                prev->next=curr;
                //free(temp);
                
                if(curr==curr->next&&curr->BT<=time_slice){
                    //printf("P%d: running for %d bursts\n",curr->ID,curr->BT);
                    tail=NULL;
                    flag=0;
                }
            }
        }
    }
    else{
        printf("** No processes present in ready queue\n");
    }
}

int main(){
    int choice,id,bt;
    printf("\n** Round-Robin Menu **\n");
    printf("1. Add a process\n");
    printf("2. View ready queue\n");
    printf("3. Start execution\n");
    printf("4. Enter time slice(default=1): \n");
    printf("5. Exit");
    do{
        printf("\n\nEnter your choice: "); scanf("%d", &choice);
        //printf("Your choice was: %d\n",choice);
        switch(choice){
            case 1: printf("Enter process id: "); scanf("%d", &id);
                    printf("Enter burst time: "); scanf("%d", &bt);
                    addProcessToList(id,bt);
                    break;
            case 2: display();
                    break;
            case 3: startExecution();
                    break;
            case 4: printf("Enter time slice: "); scanf("%d",&time_slice);
                    break;
            default: if(choice!=5)
                        printf("INVALID CHOICE!!\n");
        }
    }while(choice!=5);
    return 0;
}
