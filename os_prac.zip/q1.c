#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>

int main(){
	int a=10;
	pid_t pid;
	fork();
	if(pid==0)
		a++;
	else{
		wait(NULL);
		a--;
	}
	printf("%d\n",a );
}