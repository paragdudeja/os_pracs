#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
static int x=5;
int main(int argc, char const *argv[])
{
	pid_t pid;
	pid=fork();
	//pid=fork();
	//pid=fork();
	if(pid<0){
		printf("Fork failed\n");
	}
	else if (pid==0)
	{
		x=7;
		printf("In Child: %d  process id:%d parent id: %d value of x=%d\n",pid,getpid(),getppid(),x);
		//execlp("/bin/ls","ls",NULL);
		printf("In Child: %d  process id:%d parent id: %d\n",pid,getpid(),getppid());
	}
	else{
		wait(NULL);
		printf("In Parent:  it's child'd is : %d  process id:%d parent id: %d value of x=%d\n",pid,getpid(),getppid(),x);
	}

	return 0;
}