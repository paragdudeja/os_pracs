#include<iostream>
#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
using namespace std;

int main()
{
pid_t pid;
pid=fork();
if(pid<0)
{
cout<<"new process not entered";
}
else if(pid==0){
cout<<"Child process";
}
else
cout<<"parent process";
return 0;
}