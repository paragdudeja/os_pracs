#include<stdio.h>
#include <iostream>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
using namespace std;

int main(){
pid_t pid;
pid=fork();
if(pid<0){
cout<<"No process entered";
}
else if(pid==0){
execlp("/bin/ls","ls",NULL);
cout<<"child process";
}
else {
wait(NULL);
cout<<"parent process";
}
return 0;
}