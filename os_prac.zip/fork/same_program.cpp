#include<iostream>
#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
using namespace std;

int main()
{
    pid_t pid;
    pid=fork();
    if(pid<0)
    {
        cout<<"this is a process";
    }
    else
    {
        cout<<"process continues";
    }
    return 0;
}    