// Display the details of a file

using namespace std;
#include <iostream>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <pwd.h>

void displayTime(long t)
{
	struct tm *tp = localtime(&t);
	cout << tp -> tm_hour << ":" << tp -> tm_min << ":" << tp -> tm_sec;
	cout << "  " << tp -> tm_mday << "-" << tp -> tm_mon + 1 << "-";
	cout <<	tp -> tm_year + 1900;
}

int main()
{
	struct stat statBuf;
	struct passwd *pass;
	char filename[30];

	cout << "Enter the filename: ";
	cin >> filename;
	if (stat(filename, &statBuf) < 0)
	{
		cout << "Some error";
		exit(1);
	}
	cout << "Owner ID: " << statBuf.st_uid;
	pass = getpwuid(statBuf.st_uid);
	cout << "\tName: " << pass -> pw_name;

	cout << "\nAccess permissions: ";
	if (statBuf.st_mode & 0x0100)
		cout << "r";
	else
		cout << "-";
	if (statBuf.st_mode & 0x0080)
		cout << "w";
	else
		cout << "-";
	if (statBuf.st_mode & 0x0040)
		cout << "x";
	else
		cout << "-";
	if (statBuf.st_mode & 0x0020)
		cout << "r";
	else
		cout << "-";
	if (statBuf.st_mode & 0x0010)
		cout << "w";
	else
		cout << "-";
	if (statBuf.st_mode & 0x0008)
		cout << "x";
	else
		cout << "-";
	if (statBuf.st_mode & 0x0004)
		cout << "r";
	else
		cout << "-";
	if (statBuf.st_mode & 0x0002)
		cout << "w";
	else
		cout << "-";
	if (statBuf.st_mode & 0x0001)
		cout << "x";
	else
		cout << "-";

	cout << "\nAccess times:";
	cout << "\n\tLast access: "; displayTime(statBuf.st_atime);
	cout << "\n\tLast modification: "; displayTime(statBuf.st_mtime);
	cout << "\n\tLast status change: "; displayTime(statBuf.st_ctime);
	cout << "\n";
	return 0;
}
