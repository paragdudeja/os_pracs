#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>

int main(){
	int i;
	printf("Hello\n");
	for (int i = 1; i < 3; ++i)
		fork();
	printf("Over\n");
	return 0;
}