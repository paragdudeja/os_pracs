// 19.01.09
// Q4a Copy File

#include <fstream>
#include<cstdio>
using namespace std;
#include<unistd.h>
#include <iostream>
#include <fcntl.h>

int main()
{
	char sfile[30], tfile[30], buf[1000];
	int sd, td, n;

	cout << "Enter the source filename: ";
	cin >> sfile;
	cout << "Enter the target filename: ";
	cin >> tfile;
	if ((sd = open(sfile, O_RDONLY)) < 0)
	{
		cout << "Error opening file";
		exit(1);
	}
	if ((td = open(tfile,O_CREAT|O_WRONLY, 0666)) < 0)
	{
		cout << "Error creating file";
		close(sd);
		exit(2);
	}
	while ((n = read(sd, buf, sizeof(buf))) > 0)
		write(td, buf, n);
	close(sd);
	close(td);
	cout << "File copied";

	cout << "\n";
	return 0;
}
