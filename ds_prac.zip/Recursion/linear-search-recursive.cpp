#include<iostream>
using namespace std;

int search(int A[],int n,int data){
    if(n<0)
        return n;
    if(A[n-1]==data)
        return n-1;
    else
        return search(A,n-1,data);
}

int main(){
    int A[]={5,3,7,4,2,9,11,10};
    int n=8;
    int loc=search(A,n,7);
    if(loc>=0)
        cout<<"Found at: "<<loc<<endl;
    else
        cout<<"Not found\n";
}