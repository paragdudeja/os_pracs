#include<iostream>
using namespace std;

double expo(double base,int power){
    if(power==0)
        return 1;
    else
        return base*expo(base,power-1);
}

int main(){
    cout<<expo(9,3)<<endl;
}