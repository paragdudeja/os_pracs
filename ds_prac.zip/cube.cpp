#include <iostream>
using namespace std;

void cube(int n){
	if(n>=1){
		cube(n-1);
		cout<<n*n*n<<' ';
	}
}

int main(int argc, char const *argv[])
{
	cube(8);
	return 0;
}