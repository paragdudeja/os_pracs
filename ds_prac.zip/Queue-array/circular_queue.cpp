#include <iostream>
#define MAX 5
using namespace std;

class Queue{
	int front,rear;
	int Q[MAX];
public:
	Queue(){
		front=-1;
		rear=-1;
	}

	bool enqueue(int el){
		if(!isFull()){
			if(front==-1) front=0;
			rear=(rear+1)%MAX;
			Q[rear]=el;
			cout<<"Front: "<<front;
			cout<<"\nRear: "<<rear<<endl;
			return true;
		}
		else
			return false;
	}

	int dequeue(){
		int el;
		if(!isEmpty()){
			el=Q[front];
			if(front!=rear){
				front=(front+1)%MAX;
			}
			else{
				front=-1;
				rear=-1;
			}
			cout<<"Front: "<<front;
			cout<<"\nRear: "<<rear<<endl;
			return el;
		}
		else
			return -1;
	}

	bool isEmpty(){
		if(front==-1)
			return true;
		else
			return false;
	}

	bool isFull(){
		if((rear+1)%MAX==front)
			return true;
		else
			return false;
	}

	void displayQueue(){
		cout<<endl;
		if(!isEmpty()){
			int i=front;
			if(front<=rear)
				while(i<=rear)
					cout<<Q[i++]<<endl;
			else{
				while(i!=rear){
					cout<<Q[i++]<<endl;
					i=i%MAX;
				}
				cout<<Q[i]<<endl;
			}
		}

		
		else
			cout<<"Empty Queue!!\n";
	}
};


int main(int argc, char const *argv[])
{
	Queue queue;
	int choice,el;
	do{
		cout<<"\nQUEUE MENU\n";
		cout<<"1. enqueue\n";
		cout<<"2. dequeue\n";
		cout<<"3. displayQueue\n";
		cout<<"4. Exit\n";
		cout<<"Enter your choice: "; cin>>choice;
		switch(choice){
			case 1:
					cout<<"Enter element: "; cin>>el;
					if(!queue.enqueue(el))
						cout<<"Queue isFull\n";
					break;
			case 2: 
					el=queue.dequeue();
					if(el!=-1)
						cout<<el<<" removed from queue..\n";
					else
						cout<<"Queue isEmpty\n";
					break;
			case 3:
					queue.displayQueue();
					break;
			default:
					if(choice!=4)
						cout<<"INVALID OPTION!!!\n";

		}
	}while(choice!=4);
	/*queue.displayQueue();
	queue.enqueue(5);
	queue.enqueue(7);
	queue.enqueue(6);
	queue.enqueue(9);
	queue.enqueue(4);
	queue.enqueue(1);
	queue.displayQueue();*/
	return 0;
}