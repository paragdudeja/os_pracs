#include<iostream>
using namespace std;

class DiagonalMatrix{
    int *ar;
    int n;
public:
    DiagonalMatrix(int size){
        ar=new int[size];
        n=size;
    }

    void store(int i,int j,int data){
        *(ar+i)=data;
    }

    int retrieve(int i,int j){
        if(i==j)
            return *(ar+i);
        else
            return 0;
    }

    void displayTwoD(){
         for(int i=0;i<n;i++){
            for(int j=0;j<n;j++)
                cout<<retrieve(i,j)<<' ';
            cout<<endl;
        }
    }
};

int main(){
    int rows,i,j,choice,el,n;
    cout<<"Enter no. of rows/columns in square matrix: "; cin>>rows;
    DiagonalMatrix dm(rows);
    n=rows;
    cout<<"\nMENU\n";
    cout<<"1. Store\n";
    cout<<"2. Retrieve\n";
    cout<<"3. Display matrix\n";
    cout<<"4. Exit\n";

    do{
        cout<<"\nEnter your choice: "; cin>>choice;
        switch(choice){
            case 1: cout<<"Enter row: "; cin>>i;
                    cout<<"Enter column: "; cin>>j;
                    if(i<0||i>=n||j<0||j>=n)
                        cout<<"Index out of bounds\n";
                    else{
                        cout<<"Enter element: "; cin>>el;
                        if(i!=j&&el!=0)
                            cout<<"Invalid index to store non-zero element!!\n";
                        else
                            dm.store(i,j,el);
                    }
                    break;
            case 2: cout<<"Enter row: "; cin>>i;
                    cout<<"Enter column: "; cin>>j;
                    if(i<0||i>=n||j<0||j>=n)
                        cout<<"Index out of bounds\n";
                    else
                        cout<<"Element is: "<<dm.retrieve(i,j)<<endl;
                    break;
            case 3: dm.displayTwoD();
                    break;
            default: if(choice!=4)
                        cout<<"INVALID CHOICE!!";
        }
    }while(choice!=4);
    return 0;
}