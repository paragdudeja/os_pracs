#include<iostream>
using namespace std;

class UpperTriangular{
    int *ar;
    int n;
public:
    UpperTriangular(int size){
        ar=new int[size*(size+1)/2];
        n=size;
    }

    void store(int i,int j,int data){
        int k=j*(j+1)/2 +i;
        *(ar+k)=data;
    }

    int retrieve(int i,int j){
        if(i>j)
            return 0;
        else{
            int k=j*(j+1)/2+i;
            return *(ar+k);
        }
    }

    void displayTwoD(){
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++)
                cout<<retrieve(i,j)<<' ';
            cout<<endl;
        }
    }
};

int main(){
    int n,i,j,el,choice;
    cout<<"Enter the number of rows/columns in square matrix: "; cin>>n;
    UpperTriangular ut(n);
    cout<<"\nMAIN MENU\n";
    cout<<"1. Store\n";
    cout<<"2. Retrieve\n";
    cout<<"3. Display matrix\n";
    cout<<"4. Exit\n";
    do{
        cout<<"\nEnter your choice: "; cin>>choice;
        switch(choice){
            case 1  : cout<<"Enter row: "; cin>>i;
                      cout<<"Enter column: "; cin>>j;
                      if(i<0||i>=n||j<0||j>=n)
                          cout<<"Index out of bounds\n";
                      else{
                          cout<<"Enter element: "; cin>>el;
                          if(i<=j||el==0)
                              ut.store(i,j,el);
                          else
                              cout<<"Invalid index to store non zero elemet!!\n";
                      }
                      break;
            case 2  : cout<<"Enter row: "; cin>>i;
                      cout<<"Enter column: "; cin>>j;
                      if(i<0||i>=n||j<0||j>=n)
                          cout<<"Index out of bounds\n";
                      else
                          cout<<"Element is: "<<ut.retrieve(i,j)<<endl;
                      break;
            case 3  : ut.displayTwoD();
                      break;
            default : if(choice!=4)
                          cout<<"INVALID CHOICE!!\n";
        }
    }while(choice!=4);
    return 0;
}
