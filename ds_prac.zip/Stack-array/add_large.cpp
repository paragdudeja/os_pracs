#include <iostream>
#include <iomanip>
using namespace std;
#define MAX 50
class Stack{
	int tos;
	int S[MAX];
public:
	Stack(){
		tos=-1;
	}
	int push(int el){
		if(!isFull()){
			S[++tos]=el;
			return 1;
		}
		else 
			return -1; 

	}

	int pop(){
		if(!isEmpty()){
			int el=S[tos--];
			return el;
		}
		else
			return -1;
	}

	void displayStack(){
		//cout<<endl;
		for (int i = tos; i>=0 ; i--)
		{
			cout<<S[i];
		}
	}

	void displayNumber(){
		for (int i = 0; i<=tos ; i++)
		{
			cout<<S[i];
		}
	}

	bool isEmpty(){
		if(tos==-1)
			return 1;
		else
			return 0;
	}

	bool isFull(){
		if(tos==MAX-1)
			return 1;
		else
			return 0;
	}

};

int main(int argc, char const *argv[])
{
	Stack st1,st2,st3;
	int nod1,nod2,i,dig;
	cout<<"Enter the number of digits in first number: "; cin>>nod1;
	cout<<"Enter first number: \n";
	for(i=0;i<nod1;i++){
		cin>>dig;
		st1.push(dig);
	}

	cout<<"Enter the number of digits in second number: "; cin>>nod2;
	cout<<"Enter second number: \n";
	for(i=0;i<nod2;i++){
		cin>>dig;
		st2.push(dig);
	}
	int diff=nod1-nod2;
	cout<<setw(18)<<"First number: "<<setw(3); st1.displayNumber();
	cout<<endl<<setw(18)<<"Second number: "<<setw(3+diff); st2.displayNumber();

	int a,b,c,carry=0;

	while(!(st1.isEmpty()&&st2.isEmpty())){
		a=st1.pop();
		b=st2.pop();
		if(a==-1) a=0;
		if(b==-1) b=0;
		c=(a+b+carry)%10;
		carry=(a+b+carry)/10;
		if(st3.push(c));
	}
	if(carry!=0)
		if(st3.push(carry));

	cout<<endl<<setw(18)<<"Sum: "<<setw(3-carry); st3.displayStack();
	cout<<endl;

	return 0;
}