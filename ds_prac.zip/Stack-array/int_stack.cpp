#include <iostream>
#define MAX 5
using namespace std;

class Stack{
	int tos;
	int S[MAX];
public:
	Stack(){
		tos=-1;
	}
	int push(int el){
		if(!isFull()){
			S[++tos]=el;
			return 1;
		}
		else 
			return -1; 

	}

	int pop(){
		if(!isEmpty()){
			int el=S[tos--];
			return el;
		}
		else
			return -1;
	}

	void displayStack(){
		cout<<endl;
		for (int i = tos; i>=0 ; i--)
		{
			cout<<S[i]<<endl;
		}
	}

	bool isEmpty(){
		if(tos==-1)
			return 1;
		else
			return 0;
	}

	bool isFull(){
		if(tos==MAX-1)
			return 1;
		else
			return 0;
	}

};

int main(int argc, char const *argv[])
{
	Stack st1;
	int choice;
	do{
		cout<<"\nSTACK MENU\n";
		cout<<"1. Push\n";
		cout<<"2. Pop\n";
		cout<<"3. Display stack\n";
		cout<<"4. Exit\n";
		cout<<"Enter your choice: "; cin>>choice;
		switch(choice){
			case 1: int el;
					cout<<"Enter element: "; cin>>el;
					if(st1.push(el)==1)
						cout<<el<<" pushed..\n";
					else
						cout<<"OVERFLOW!! Stack is full..\n";
					break;
			case 2: 
					el=st1.pop();
					if(el!=-1)
						cout<<el<<" popped ..\n";
					else
						cout<<"UNDERFLOW!! Stack is empty..\n";
					break;
			case 3: 
					st1.displayStack();
					break;
			default:
					if(choice!=4)
						cout<<"Invalid CHOICE!!\n";

		}
	}while(choice!=4);


	return 0;
}