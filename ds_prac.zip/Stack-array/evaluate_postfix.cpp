#include <iostream>
#define MAX 50
using namespace std;

template<class T> 
class Stack{
	int tos;
	T S[MAX];
public:
	Stack(){
		tos=-1;
	}
	bool push(T el){
		if(!isFull()){
			S[++tos]=el;
			return true;
		}
		else 
			return false; 

	}

	T pop(){
		if(!isEmpty()){
			T el=S[tos--];
			return el;
		}
		else
			return -1;
	}

	void displayStack(){
		cout<<endl;
		for (int i = tos; i>=0 ; i--)
		{
			cout<<S[i]<<endl;
		}
	}

	bool isEmpty(){
		if(tos==-1)
			return 1;
		else
			return 0;
	}

	bool isFull(){
		if(tos==MAX-1)
			return 1;
		else
			return 0;
	}

};

int main(int argc, char const *argv[])
{
	Stack<int> st1;
	//int choice;
	char el;
	char str[30];
	cout<<"Enter the postfix expression: ";
	cin>>str;
	int dig,result;
	for(int i=0;str[i]!='\0';i++){
		if(isdigit(str[i])){
			dig=str[i]-48;
			st1.push(dig);
		}
		else{
			int a,b;
			b=st1.pop();
			a=st1.pop();
			switch(str[i]){
				case '+':
						result=a+b;
						break;
				case '-':
						result=a-b;
						break;
				case '*':
						result=a*b;
						break;
				case '/':
						result=a/b;
						break;
			}
			st1.push(result);
		}

	}
	cout<<result<<endl;
	return 0;
}
