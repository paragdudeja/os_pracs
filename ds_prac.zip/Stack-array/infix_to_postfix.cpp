#include <iostream>
#include <cctype>
#define MAX 50
using namespace std;

template<class T> 
class Stack{
	int tos;
	T S[MAX];
public:
	Stack(){
		tos=-1;
	}
	bool push(T el){
		if(!isFull()){
			S[++tos]=el;
			return true;
		}
		else 
			return false; 

	}

	T pop(){
		if(!isEmpty()){
			T el=S[tos--];
			return el;
		}
		else
			return -1;
	}

	void displayStack(){
		cout<<endl;
		for (int i = tos; i>=0 ; i--)
		{
			cout<<S[i]<<endl;
		}
	}

	bool isEmpty(){
		if(tos==-1)
			return 1;
		else
			return 0;
	}

	bool isFull(){
		if(tos==MAX-1)
			return 1;
		else
			return 0;
	}

	T getTop(){
		if(!isEmpty())
			return S[tos];
		else
			return -1;
	}

};

int main(int argc, char const *argv[])
{
	Stack<char> st1;
	//int choice;
	char str[30],ch;
	int i;
	cout<<"Enter the infix expression: ";
	cin>>str;
	cout<<"Equivalent postfix expression: ";
	for(i=0;str[i]!='\0';i++){
		if(isalnum(str[i]))
			cout<<str[i];
		else{
			char ch=st1.getTop();

			if(str[i]=='*'||str[i]=='/'||str[i]=='%')
				while((ch=='*'||ch=='/')){
					cout<<st1.pop();
					ch=st1.getTop();
				}

			else if(str[i]=='+'||str[i]=='-')
				while(!st1.isEmpty()){
					cout<<st1.pop();
					ch=st1.getTop();
				}
			st1.push(str[i]);	
		}
	}
	while(!st1.isEmpty())
		cout<<st1.pop();
	cout<<endl;
	return 0;
}
