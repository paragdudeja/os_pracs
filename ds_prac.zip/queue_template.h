#define SIZE 200

template<class T>
class Queue{
private:
	int front,rear;
	T Q[SIZE];
public:
	Queue(){
		front=rear=-1;
	}
	bool isEmpty(){
		if(front==-1)
			return true;
		else
			return false;
	}

	void enqueue(T el){
		if(front==-1){
			front=rear=0;
			Q[rear]=el;
		}
		else{
			if((rear+1)!=SIZE)
				Q[++rear]=el;
		}
	}

	T dequeue(){
		T temp;
		if(front==rear){
			temp= Q[front];
			front=rear=-1;
		}
		else{
			temp=Q[front++];
		}
		return temp;
	}
};