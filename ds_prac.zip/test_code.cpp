#include<iostream>
using namespace std;
int main(int argc, char const *argv[])
{
	int a=- 7,b=-4;
	cout<<a%b<<endl;
	return 0;
}