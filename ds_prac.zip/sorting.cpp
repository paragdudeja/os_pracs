#include<iostream>
using namespace std;

void swap(int &a,int &b){
	int temp=a;
	a=b;
	b=temp;
}

void display(int B[],int n){
	for(int i=0;i<n;i++)
		cout<<B[i]<<' ';
	cout<<endl;
}

void selectionSort(int B[],int n){
	int min;
	for(int i=0;i<n;i++){
		min=i;
		for(int j=i+1;j<n;j++){
			if(B[j]<B[min])
				min=j;
		}
		if(min!=i)
			swap(B[min],B[i]);
		cout<<"Array after pass "<<i+1<<": "; display(B,n);
	}
}

void bubbleSort(int B[],int n){
	for(int i=0;i<n;i++){
		for(int j=0;j<n-i;j++){
			if(B[j]>B[j+1])
				swap(B[j],B[j+1]);
		}
		cout<<"Array after pass "<<i+1<<": "; display(B,n);
	}
}

void insertionSort(int B[],int n){
	int i,j,temp;
    for(i=1;i<n;i++)
    {
    	temp=B[i];
    	j=i-1;
    	while((temp<B[j])&&(j>=0))
    	{
        	B[j+1]=B[j];
        	j--;
    	}
    	B[j+1]=temp;
    	cout<<"Array after pass "<<i<<": "; display(B,n);
    }	
}

int linearSearch(int B[],int n,int data){
	int pos=-1;
	for(int i=0;i<n;i++)
		if(B[i]==data){
			pos=i;
			break;
		}
	return pos;
}

int binarySearch(int B[],int n,int data){
	int begin=0,end=n-1,mid,pos=-1;
	while(begin<=end){
		mid=(begin+end)/2;
		if(B[mid]==data){
			pos=mid;
			break;
		}
		if(B[mid]<data)
			begin=mid+1;
		else
			end=mid-1;
	}
	return pos;
}

void copyToB(int A[],int B[],int n){
	for(int i=0;i<n;i++)
		B[i]=A[i];
}

void merge(int arr[], int l, int m, int r) 
{ 
    int i, j, k; 
    int n1 = m - l + 1; 
    int n2 =  r - m; 
  
    /* create temp arrays */
    int L[n1], R[n2]; 
  
    /* Copy data to temp arrays L[] and R[] */
    for (i = 0; i < n1; i++) 
        L[i] = arr[l + i]; 
    for (j = 0; j < n2; j++) 
        R[j] = arr[m + 1+ j]; 
  
    /* Merge the temp arrays back into arr[l..r]*/
    i = 0; // Initial index of first subarray 
    j = 0; // Initial index of second subarray 
    k = l; // Initial index of merged subarray 
    while (i < n1 && j < n2) 
    { 
        if (L[i] <= R[j]) 
        { 
            arr[k] = L[i]; 
            i++; 
        } 
        else
        { 
            arr[k] = R[j]; 
            j++; 
        } 
        k++; 
    } 
  
    /* Copy the remaining elements of L[], if there 
       are any */
    while (i < n1) 
    { 
        arr[k] = L[i]; 
        i++; 
        k++; 
    } 
  
    /* Copy the remaining elements of R[], if there 
       are any */
    while (j < n2) 
    { 
        arr[k] = R[j]; 
        j++; 
        k++; 
    } 
} 
  
/* l is for left index and r is right index of the 
   sub-array of arr to be sorted */
void mergeSort(int arr[], int l, int r) 
{ 
    if (l < r) 
    { 
        // Same as (l+r)/2, but avoids overflow for 
        // large l and h 
        int m = l+(r-l)/2; 
  
        // Sort first and second halves 
        mergeSort(arr, l, m); 
        mergeSort(arr, m+1, r); 
  
        merge(arr, l, m, r); 
    } 
} 

/* This function takes last element as pivot, places 
   the pivot element at its correct position in sorted 
    array, and places all smaller (smaller than pivot) 
   to left of pivot and all greater elements to right 
   of pivot */
int partition (int arr[], int low, int high) 
{ 
    int pivot = arr[high];    // pivot 
    int i = (low - 1);  // Index of smaller element 
  
    for (int j = low; j <= high- 1; j++) 
    { 
        // If current element is smaller than or 
        // equal to pivot 
        if (arr[j] <= pivot) 
        { 
            i++;    // increment index of smaller element 
            swap(arr[i], arr[j]); 
        } 
    } 
    swap(arr[i + 1], arr[high]); 
    return (i + 1); 
} 
  
/* The main function that implements QuickSort 
 arr[] --> Array to be sorted, 
  low  --> Starting index, 
  high  --> Ending index */
void quickSort(int arr[], int low, int high) 
{ 
    if (low < high) 
    { 
        /* pi is partitioning index, arr[p] is now 
           at right place */
        int pi = partition(arr, low, high); 
  
        // Separately sort elements before 
        // partition and after partition 
        quickSort(arr, low, pi - 1); 
        quickSort(arr, pi + 1, high); 
    } 
} 


int main(){
	int A[20],B[20],n,choice,data,loc;
	cout<<"Enter the number of elements in the array A: "; cin>>n;
	cout<<"Enter "<<n<<" elements: ";
	for(int i=0;i<n;i++)
		cin>>A[i];

	copyToB(A,B,n);

	do{
		cout<<"\n\n1. Selection sort after copying to array A to B\n";
		cout<<"2. Bubble sort after copying to array A to B\n";
		cout<<"3. Insertion sort after copying to array A to B\n";
		cout<<"4. Linear search in B\n";
		cout<<"5. Binary serach in B\n";
		cout<<"6. Copy A to B\n";
		cout<<"7. Merge sort\n";
		cout<<"8. Quick sort\n";
		cout<<"9. Exit\n";
		cout<<"Enter your choice: "; cin>>choice;
		switch(choice){
			case 1: copyToB(A,B,n);
					selectionSort(B,n);
					cout<<"\nSorted array: ";
					display(B,n);
					break;
			case 2: copyToB(A,B,n);
					bubbleSort(B,n);
					cout<<"\nSorted array: ";
					display(B,n);
					break;
			case 3: copyToB(A,B,n);
					insertionSort(B,n);
					cout<<"\nSorted array: ";
					display(B,n);
					break;
			case 4: cout<<"Enter data you want to search: "; cin>>data;
					loc=linearSearch(B,n,data);
					if(loc!=-1)
						cout<<"Element found at: "<<loc<<endl;
					else
						cout<<"Not found\n";
					break;
			case 5: cout<<"Enter data you want to search: "; cin>>data;
					loc=binarySearch(B,n,data);
					if(loc!=-1)
						cout<<"Element found at: "<<loc<<endl;
					else
						cout<<"Not found\n";
					break;
			case 6: copyToB(A,B,n);
					break;
			case 7:	copyToB(A,B,n);
					mergeSort(B,0,n-1);
					cout<<"\nSorted array: ";
					display(B,n);
					break;
			case 8: copyToB(A,B,n);
					cout<<"\nSorted array: ";
					quickSort(B,0,n-1);
					display(B,n);
					break;
			default: if(choice!=9)
						  cout<<"INVALID CHOICE!!\n";
		}
	}while(choice!=9);
}