#include<iostream>

using namespace std;

class polyNode{
public:
	int power;
	float coeff;
	polyNode *next;
	polyNode(int p,int c){
		power=p;
		coeff=c;
		next=NULL;
	}
};

class polyList{
	polyNode *head;
	polyNode *tail;
public:
	polyList(){
		head=tail=NULL;
	}

	void addToList(int p,float c){
		if(c!=0){
			polyNode *node=new polyNode(p,c);
			if(head==NULL)
				head=tail=node;
			else{
				tail->next=node;
				tail=node;
			}
		}
	}

	void display(){
		if(head!=NULL){
			polyNode *temp=head;
			while(temp!=NULL){
				cout<<' ';
				if(temp->coeff>0&&temp!=head)
					cout<<'+';
				cout<<temp->coeff;
				if(temp->power!=0)
					cout<<"x";
				if(temp->power!=0&&temp->power!=1)
					cout<<'^'<<temp->power<<" ";
				temp=temp->next;
			}
			cout<<endl;
		}
	}

	void storeResult(polyList poly1,polyList poly2){
		int deg,coefficient;
		polyNode *p1=poly1.head;
		polyNode *p2=poly2.head;
		while(p1!=NULL&&p2!=NULL){
			if(p1->power==p2->power){
				deg=p1->power;
				coefficient=p1->coeff+p2->coeff;
				addToList(deg,coefficient);
				p1=p1->next;
				p2=p2->next;
			}
			else if(p1->power>p2->power){
				addToList(p1->power,p1->coeff);
				p1=p1->next;
			}
			else{
				addToList(p2->power,p2->coeff);
				p2=p2->next;
			}
		}
		if(p1!=NULL){
			while(p1!=NULL){
				addToList(p1->power,p1->coeff);
				p1=p1->next;
			}
		}
		if(p2!=NULL){
			while(p2!=NULL){
				addToList(p2->power,p2->coeff);
				p2=p2->next;
			}
		}
	}
};

int main(){
	polyList poly1,poly2,poly3;
	int choice,deg,coeff,i;
	cout<<"POLYNOMIAL ADDITION\n";
	cout<<"Enter degree of first polynomial: "; cin>>deg;
	for(i=deg;i>=0;i--){
		cout<<"Enter the coefficient of x^"<<i<<": "; cin>>coeff;
		poly1.addToList(i,coeff);
	}
	cout<<"\nFirts polynomial: ";
	poly1.display();

	cout<<"\nEnter degree of poly2 polynomial: "; cin>>deg;
	for(i=deg;i>=0;i--){
		cout<<"Enter the coefficient of x^"<<i<<": "; cin>>coeff;
		poly2.addToList(i,coeff);
	}
	cout<<"\nSecond polynomial: ";
	poly2.display();

	poly3.storeResult(poly1,poly2);
	cout<<"\nAfter adding the two polynomials\nResult: ";
	poly3.display();
}