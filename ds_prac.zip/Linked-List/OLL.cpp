#include <iostream>
using namespace std;

class Node{
public:
	int info;
	Node *next;
	Node(int data){
		next=NULL;
		info=data;
	}
};

class OLL{
private:
	Node *head,*tail;
public:
	OLL(){
		head=tail=NULL;
	}

	void insertNode(int data){
		Node *p=new Node(data);
		if(head==NULL)
			head=tail=p;
		else{
			if(data<head->info){
				p->next=head;
				head=p;
			}
			else if(data>tail->info){
				tail->next=p;
				tail=tail->next;
			}
			else{
				Node *temp=head;
	            Node *prev=head;
	            while(((p->info)>(temp->info))&&temp!=tail){
	                prev=temp;
	                temp=temp->next;
	            }
	            (p->next)=(prev->next);
	            (prev->next)=p;
			}
		}
	}

	Node* getHead(){
		return head;
	}

	void mergeList(OLL list1,OLL list2){
		Node *l1=list1.getHead();
		Node *l2=list2.getHead();
		while(l1!=NULL){
			insertNode(l1->info);
			l1=l1->next;
		}
		while(l2!=NULL){
			insertNode(l2->info);
			l2=l2->next;
		}
	}

	void clearList(){
		head=tail=NULL;
	}

	void traverse(){
		Node *temp=head;
		while(temp!=NULL){
			visit(temp);
			temp=temp->next;
		}
	}

	void visit(Node *node){
		cout<<node->info<<endl;
	}

	bool deleteNode(int data){
		if(data<head->info||data>tail->info)
			return false;

		Node *temp=head,*prev=head;
		bool flag=false;
		if(data==head->info){
			head=head->next;
			flag=true;
		}
		else if(data==tail->info){
			while(temp!=tail){
				prev=temp;
				temp=temp->next;
			}
			tail=prev;
			tail->next=NULL;
			flag=true;
		}
		else{
			while(data>temp->info&&temp!=tail){
				prev=temp;
				temp=temp->next;
				if(data==temp->info){
					prev->next=temp->next;
					flag=true;
					break;
				}
			}
		}
		delete temp;
		return flag;
	}
};

int main(int argc, char const *argv[])
{
	OLL list1,list2,list3;
	int choice,data;
	
	do{
		cout<<"\nOrdered Linked List Menu\n";
		cout<<"--------------------------------------------------\n";
		cout<<"1. Insert to list 1\n";
		cout<<"2. Insert to list 2\n";
		cout<<"3. Display list 1\n";
		cout<<"4. Display list 2\n";
		cout<<"5. Delete from list 1\n";
		cout<<"6. Delete from list 2\n";
		cout<<"7. Merge list 1 and list 2\n";
		cout<<"8. Exit\n\n";
		cout<<"Enter your choice: "; cin>>choice;
		switch(choice){
			case 1 : cout<<"\nEnter element: "; cin>>data;
					 list1.insertNode(data);
					 break;
			case 2 : cout<<"\nEnter element: "; cin>>data;
					 list2.insertNode(data);
					 break;
			case 3 : cout<<"\nList 1\n------------\n";
					 list1.traverse();
					 break;
			case 4 : cout<<"\nList 2\n------------\n";
					 list2.traverse();
					 break;
			case 5 : cout<<"\nEnter element to delete: "; cin>>data;
					 if(list1.deleteNode(data))
						 cout<<data<<" deleted..\n";
					 else
						 cout<<"Not found!!\n";
					 break;
			case 6:  cout<<"\nEnter element to delete: "; cin>>data;
					 if(list2.deleteNode(data))
					     cout<<data<<" deleted..\n";
					 else
					 	 cout<<"Not found!!\n";
					 break;
			case 7 : list3.clearList();
					 list3.mergeList(list1,list2);
					 cout<<"\nMerged lists\n";
					 list3.traverse();
					 break;
			default: if(choice!=8)
					 	 cout<<"INVALOD CHOICE!!\n";
		}
	}while(choice!=8);
	return 0;
}