#include<iostream>
using namespace std;

template<class T>
class SLLNode{
public:
	T info;
	SLLNode *next;
	SLLNode(){
		next=NULL;	
	}	
};

template<class T>
class SLL{
public:
	SLLNode<T> *head;
	SLLNode<T> *tail;
	SLL(){
		head=NULL;
		tail=NULL;
	}
	void addAtTail(T el){
		SLLNode<T> *p=new SLLNode<T>;
		p->info=el;
		p->next=NULL;
		if(head==NULL){
			head=p;
			tail=p;
		}
		else{
			tail->next=p;
			tail=tail->next;		
		}
	}

	void traverse(){
		SLLNode<T> *temp=head;
		while(temp!=NULL){
			visit(temp);
			temp=temp->next;		
		}
	}
	
	void addAtHead(T el){
		SLLNode<T> *p=new SLLNode<T>;
		p->info=el;
		if(head==NULL){
			head=p;
			tail=p;		
		}
		else{
			p->next=head;
			head=p;		
		}
	}	
	
	void visit(SLLNode<T> *temp){
		cout<<temp->info<<endl;
	}

	bool search(T data){
		SLLNode<T> *temp=head;
		bool found=false;
		while(temp!=NULL){
			if(temp->info==data){
				found=true;
				break;
			}
			else
				temp=temp->next;
		}
		return found;
	}
	
	int nodeCounter(){
		int count=0;
		SLLNode<T> *temp=head;
		while(temp!=NULL){
			temp=temp->next;
			count++;		
		}
		return count;
	}	
	
	bool addBeforeNPosition(int data,int pos){
		SLLNode<T> *p=new SLLNode<T>;
		p->info=data;
		p->next=NULL;
		if(pos<1||pos>(nodeCounter()+1)){
			return false;
		}
		if(pos==1){
			addAtHead(data);
			return true;
		}		
		else{
			int index=2;
			SLLNode<T> *temp=head;
			while(temp!=NULL){
				if(index++==pos){
					p->next=temp->next;
					temp->next=p;
					return true;
				}
				else
					temp=temp->next;			
			}					
		}
	}

	bool deleteFromHead(){
		if(head!=NULL){
			SLLNode<T> *temp=new SLLNode<T>;
			temp=head;
			visit(temp);
			head=head->next;
			delete temp;
			return true;		
		}
		else
			return false;
	}
	
	bool deleteFromTail(){
		if(tail==NULL)
			return false;	

		if(head==tail){
			deleteFromHead();
			return true;		
		}
		else{
			SLLNode<T> *temp=new SLLNode<T>;
			temp=head;
			while(temp!=NULL){
				if(temp->next==tail){
					visit(tail);
					SLLNode<T> *temp2=tail;
					temp->next=NULL;
					tail=temp;
					delete temp2;
					return true;
				}
				else
					temp=temp->next;		
			}
		}
	}

	/* Function to reverse the linked list */
    void reverse() 
    { 
        // Initialize current, previous and 
        // next pointers 
        SLLNode<T> *current = head; 
        SLLNode<T> *prev = NULL, *next = NULL; 
  
  
        while (current != NULL) 
        { 
            // Store next 
            next = current->next; 
  
            // Reverse current node's pointer 
            current->next = prev; 
  
            // Move pointers one position ahead. 
            prev = current; 
            current = next; 
        } 
        head = prev; 
    }

    void mergeList(SLL list1,SLL list2){
    	SLLNode<T> *n1=list1.head;
    	SLLNode<T> *n2=list2.head;
    	while(n1!=NULL){
    		addAtTail(n1->info);
    		n1=n1->next;
    	}
    	while(n2!=NULL){
    		addAtTail(n2->info);
    		n2=n2->next;
    	}
//    	return SLL;
    }

    void clearList(){
    	head=tail=NULL;
    }
};


int main(){
	SLL<int> list1;
	SLL<int> list2;
	SLL<int> list3;
	int choice,el,item,pos,select;
	do{
		cout<<"\nLINKED LIST MENU\n------------------------------------------\n";
		cout<<"1.  Add at tail of list 1\n";
		cout<<"2.  Add at head of list 1\n";
		cout<<"3.  Traverse list 1\n";
		cout<<"4.  Add before Nth postion list 1\n";
		cout<<"5.  Delete from head list 1\n";
		cout<<"6.  Delete from tail list 1\n";
		cout<<"7.  Reverse the first linked list\n";
		cout<<"8.  Add at tail of list 2\n";
		cout<<"9.  Add at head of list 2\n";
		cout<<"10. Traverse list 2\n";
		cout<<"11. Add before Nth postion list 2\n";
		cout<<"12. Delete from head list 2\n";
		cout<<"13. Delete from tail list 2\n";
		cout<<"14. Reverse the second linked list \n";
		cout<<"15. Concatenate list 1 and list 2\n";
		cout<<"16. Exit\n";
		cout<<"Enter your choice: "; cin>>choice;
		switch(choice){
			case 1:
					cout<<"Enter element: "; cin>>el;
					list1.addAtTail(el);
					break;
			case 2: 
					cout<<"Enter element: "; cin>>el;
					list1.addAtHead(el);
					break;
			case 3: 
					list1.traverse();
					break;
			case 4: 
					cout<<"Enter element: "; cin>>el;
					cout<<"Enter position before which you want to add this: "; cin>>pos;
					if(!list1.addBeforeNPosition(el,pos))
						cout<<"\nBhai position dekh le daal\n";
					break;
			case 5: 
					if(!list1.deleteFromHead())
						cout<<"\nList 1 is empty\n";
					else
						cout<<" deleted..\n";
					break;
			case 6:
					if(!list1.deleteFromTail())
						cout<<"\nList 1 is empty\n";
					else
						cout<<" deleted..\n";
					break;
			case 7: 
					list1.reverse();
					cout<<"Reversed list 1:\n";
					list1.traverse();
					break;
			case 8:
					cout<<"Enter element: "; cin>>el;
					list2.addAtTail(el);
					break;
			case 9: 
					cout<<"Enter element: "; cin>>el;
					list2.addAtHead(el);
					break;
			case 10: 
					list2.traverse();
					break;
			case 11: 
					cout<<"Enter element: "; cin>>el;
					cout<<"Enter position before which you want to add this: "; cin>>pos;
					if(!list2.addBeforeNPosition(el,pos))
						cout<<"\nBhai position dekh le daal\n";
					break;
			case 12: 
					if(!list2.deleteFromHead())
						cout<<"\nList is empty\n";
					break;
			case 13:
					if(!list1.deleteFromTail())
						cout<<"\nList is empty\n";
					break;
			case 14:
			 		list1.reverse();
					cout<<"Reversed list 1:\n";
					list1.traverse();
					break;
			case 15:
					list3.clearList();
					list3.mergeList(list1,list2);
					cout<<"Merged list\n";
					list3.traverse();
					break;
			default:
					if(choice!=16)
						cout<<"INVALID CHOICE!!!";
		}	
	}while(choice!=16);



	return 0;
}