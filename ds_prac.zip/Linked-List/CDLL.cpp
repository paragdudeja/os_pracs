#include<iostream>
using namespace std;

class CLLNode{
public:
	int info;
	CLLNode *prev;
	CLLNode *next;
	CLLNode(){
		prev=next=NULL;
	}
};

class CDLL{
	CLLNode *head;
public:
	CDLL(){
		head=NULL;
	}

	void addAtHead(int data){
		CLLNode *node=new CLLNode;
		node->info=data;
		if(head==NULL){
			head=node;
			node->prev=node;
			node->next=node;
		}
		else{
			CLLNode *last=head->prev;
			node->next=head;
			node->prev=last;
			last->next=node;
			head->prev=node;
			head=node;
		}
	}

	int deleteNthElement(int pos){
		if(pos<1||head==NULL)
			return -1;
		int count=0;
		CLLNode *temp=head;
		while(++count<pos){
			temp=temp->next;
			if(temp==head)
				return -1;
		}
		int data=temp->info;
		(temp->prev)->next=temp->next;
		(temp->next)->prev=temp->prev;
		delete temp;
		return data;
	}


	int displayNthElement(int pos){
		if(pos<1||head==NULL)
			return -1;
		int count=0;
		CLLNode *temp=head;
		while(++count<pos){
			temp=temp->next;
			if(temp==head)
				return -1;
		}
		int data=temp->info;
		return data;
	}


	double findAverage(){
		if(head!=NULL){
			CLLNode *temp=head;
			double sum=0,average;
			int count=0;
			do{
				count++;
				sum+=temp->info;
				//cout<<temp->info<<endl;
				temp=temp->next;
			}while(temp!=head);
			average=sum/count;
			return average;
		}
		else
			return 0;
	}

	int findMiddle(){
		if(head!=NULL){
			CLLNode *forward=head;
			CLLNode *backward=head->prev;
			while(true){
				if(forward==backward)
					return (forward->info);
				else if(forward->next==backward)
					return (forward->info);
				else{
					forward=forward->next;
					backward=backward->prev;
				}
			}
		}
		else return -1;
	}

	void display(){
		if(head!=NULL){
			CLLNode *temp=head;
			do{
				cout<<temp->info<<endl;
				temp=temp->next;
			}while(temp!=head);
		}
	}
};

int main(int argc, char const *argv[])
{
	CDLL list;
	list.addAtHead(5);
	list.addAtHead(7);
	list.addAtHead(18);
	list.addAtHead(4);
	list.addAtHead(13);
	list.display();
	cout<<list.displayNthElement(2)<<endl;
	//cout<<list.findAverage()<<endl;
	//cout<<list.findMiddle()<<endl;
	cout<<list.deleteNthElement(3)<<endl;
	list.display();
	return 0;
}