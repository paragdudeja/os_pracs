#include <iostream>
using namespace std;

template<class T>
class StackNode{
public:
	T info;
	StackNode *link;
	StackNode(){
		link=NULL;
	}
};

template<class T>
class stack
{
	StackNode<T> *top;
public:
	stack(){
		top=NULL;
	}

	void push(T data){
		StackNode<T> *node=new StackNode<T>;
		node->info=data;
		if(top==NULL)
			top=node;
		else{
			node->link=top;
			top=node;
		}
	}

	T pop(){
		if(!isEmpty()){
			T data=top->info;
			StackNode<T> *temp=new StackNode<T>;
			temp=top;
			top=top->link;
			delete temp;
			return data;
		}
		else
			return -1;
	}

	void display(){
		if(top!=NULL){
			StackNode<T> *temp=new StackNode<T>;
			temp=top;
			while(temp!=NULL){
				cout<<temp->info<<endl;
				temp=temp->link;
			}
		}
	}
	
	bool isEmpty(){
		if(top==NULL)
			return true;
		else
			return false;
	}
};



int main(int argc, char const *argv[])
{
	stack<int> st;
	int choice,el;
	do{
		cout<<"\nSTACK MENU\n";
		cout<<"1. push\n";
		cout<<"2. pop\n";
		cout<<"3. display\n";
		cout<<"4. Exit\n";
		cout<<"Enter your choice: "; cin>>choice;
		switch(choice){
			case 1:
					cout<<"Enter element: "; cin>>el;
					st.push(el);
					break;
			case 2: 
					el=st.pop();
					if(el!=-1)
						cout<<el<<" removed from stack..\n";
					else
						cout<<"Stack is Empty\n";
					break;
			case 3:
					st.display();
					break;
			default:
					if(choice!=4)
						cout<<"INVALID OPTION!!!\n";

		}
	}while(choice!=4);
	return 0;
}