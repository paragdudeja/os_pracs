#include<iostream>
#include<cctype>
using namespace std;

int size;
void sender(int i){
    cout<<"\nSequence no. : "<<i+1<< " Frame "<<i%size<<" sent";
}

void receiver(int i){
    cout<<"\nACK"<<i<<" received by the sender\n"; 
}

int main(){
    int no_of_frames,i=0,j;
    char ch;
    cout<<"Enter size of sliding window: "; cin>>size;
    cout<<"Enter no. of frames: "; cin>>no_of_frames;
    while(i<no_of_frames){
        j=i;
        sender(i);
        if((i+1)%size==0){
            cout<<"\nWant to introduce noise(y/n): "; cin>>ch;
            if(ch=='n')
                receiver((i+1)%size);
            else
                i-=4;
            cout<<endl;
        }
        i++;
    }
    return 0;
}