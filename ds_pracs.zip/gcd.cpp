#include<iostream>
using namespace std;
int gcdRecur(int,int);
int gcdLoop(int,int);

int main()
{
	int num1,num2;
    do
    {
        cout<<"Enter a no. : "; cin>>num1;
        if(num1<1||num1>32000)
            cout<<"Enter a no. between 1 and 32000 only!!";
    }while(num1<1||num1>32000);
	do
    {
        cout<<"Enter a no. : "; cin>>num2;
        if(num2<1||num2>32000)
            cout<<"Enter a no. between 1 and 32000 only!!";
    }while(num2<1||num2>32000);
    cout<<"GCD using recursion: "<<gcdRecur(num1,num2)<<endl;
	cout<<"GCD using iteration: "<<gcdLoop(num1,num2);
	return 0;
}

int gcdRecur(int n1,int n2)
{
	if(n2==0)
		return n1;
	else
		return gcdRecur(n2,n1%n2);
}

int gcdLoop(int n1,int n2)
{
	while(n1 != n2)
    {
        if(n1 > n2)
            n1 -= n2;
        else
            n2 -= n1;
    }

    return n1;
}
