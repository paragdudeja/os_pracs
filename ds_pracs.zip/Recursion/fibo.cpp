#include<iostream>
using namespace std;

int fibo(int n){
    if(n==1)
        return 0;
    if(n==2)
        return 1;
    else{
        return fibo(n-1)+fibo(n-2);
    }
}

int main(){
    int n1=0,n2=1,n,i;
    do{
        cout<<"Enter the no. of terms in the fibonacci series: "; cin>>n;
    }while(n<1||n>40);
    cout<<n1<<' '<<n2<<' ';
    for(i=3;i<=n;i++)
        cout<<fibo(i)<<' ';
}