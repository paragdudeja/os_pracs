#include<iostream>
using namespace std;

class Node{
public:
    int info;
    Node *next;
    Node(){
        next=NULL;
    }
};

class SLL{
    Node *head;
    Node *tail;
public:
    SLL(){
        head=tail=NULL;
    }

    void insertNode(int el){
        Node *p=new Node;
        p->info=el;
        if(head==NULL){
            head=tail=p;
            return;
        }
        else{
            if(p->info<head->info){
                p->next=head;
                head=p;
                return;
            }
            else if(p->info>tail->info){
                tail->next=p;
                tail=p;
                return;
            }
            else{
                Node *temp=head;
                Node *prev=head;
                while(((p->info)>(temp->info))&&temp!=tail){
                    prev=temp;
                    temp=temp->next;
                }
                (p->next)=(prev->next);
                (prev->next)=p;
            }
        }
    }

    void display(){
        Node *temp=head;
        while(temp!=NULL){
            cout<<temp->info<<endl;
            temp=temp->next;
        }
    }
};

int main(){
    int choice,el;
    SLL sll;
    cout<<"MENU\n";
    cout<<"1. Insert\n";
    cout<<"2. Display\n";
    cout<<"3. Exit";
    do{
        cout<<"\n\nEnter your choice: "; cin>>choice;
        switch(choice){
            case 1: cout<<"Enter element: "; cin>>el;
                    sll.insertNode(el);
                    break;
            case 2: sll.display();
                    break;
            default: if(choice!=3)
                        cout<<"INVALID CHOICE!!\n";
        }
    }while(choice!=3);
}