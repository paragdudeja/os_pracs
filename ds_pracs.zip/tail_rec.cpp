#include <iostream>
using namespace std;

void tail(int n){
	if(n>0){
//		cout<<n<<' ';
		tail(n-1);
		cout<<n<<' ';
//		tail(n-1);
	}
}

int main(int argc, char const *argv[])
{
	tail(8);
	return 0;
}