#include<iostream>
using namespace std;

class QueueNode{
public:
    int info;
    QueueNode *next;
    QueueNode(){
        next=NULL;
    }
};

class Queue{
public:
    QueueNode *front;
    QueueNode *rear;
    Queue(){
        front=rear=NULL;
    }

    void enqueue(int el){
        QueueNode *node=new QueueNode;
        node->info=el;
        if(front==NULL)
            front=rear=node;
        else{
            rear->next=node;
            rear=rear->next;
        }
    }

    int dequeue(){
        if(!isEmpty()){
            QueueNode *temp=new QueueNode;
            temp=front;
            int data=front->info;
            if(front==rear)
                front=rear=NULL;
            else
                front=front->next;
            delete temp;
            return data;
        }
        else
            return -1;
    }

    bool isEmpty(){
        if(front==NULL)
            return true;
        else
            return false;
    }

    void display(){
        if(!isEmpty()){
            QueueNode *temp=new QueueNode;
            temp=front;
            while(temp!=NULL){
                cout<<temp->info<<endl;
                temp=temp->next;
            }
        }
    }
};

int main(){
    Queue q;
    int choice,get;
    do{
        cout<<"\nQUEUE MENU\n";
        cout<<"1. Enqueue\n";
        cout<<"2. Dequeue\n";
        cout<<"3. Display\n";
        cout<<"4. Exit\n";
        cout<<"Enter your choice: "; cin>>choice;
        switch(choice){
            case 1: cout<<"Enter an element: "; cin>>get;
                    q.enqueue(el);
                    break;
            case 2: int get=q.dequeue();
                    if(get!=-1)
                        cout<<get<<" removed from queue...\n";
                    else
                        cout<<"Queue is empty\n";
                    break;
            case 3: q.display();
                    break;
            default:if(choice!=4)
                        cout<<"INVALID CHOICE";
        }
    }while(choice!=4);
    return 0;
}