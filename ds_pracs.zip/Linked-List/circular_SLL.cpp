#include <iostream>
using namespace std;

class CLLNode{
public:
	int info;
	CLLNode *next;
	CLLNode(){
		next=NULL;
	}
};

class CLL{
public:
	CLLNode *tail;
	CLL(){
		tail=NULL;
	}

	void addAtTail(int data){
		CLLNode *p=new CLLNode;
		p->info=data;
		if(tail==NULL){
			tail=p;
			tail->next=p;
		}
		else{
			p->next=tail->next;
			tail->next=p;
			tail=tail->next;
		}
	}

	void addAtHead(int data){
		CLLNode *p=new CLLNode;
		p->info=data;
		if(tail==NULL){
			tail=p;
			tail->next=p;
		}
		else{
			p->next=tail->next;
			tail->next=p;
		}
	}

	int deleteFromHead(){
		if(!isEmpty()){
			CLLNode *temp=new CLLNode;
			temp=tail->next;
			int data=temp->info;
			if(tail==tail->next){
				tail=NULL;
			}
			else{
				tail->next=temp->next;
			}
			delete temp;
			return data;
		}
		else
			return -1;
	}

	int deleteFromTail(){
		if(!isEmpty()){
			CLLNode *temp=new CLLNode;
			temp=tail->next;
			int data=tail->info;
			CLLNode *temp2=tail;
			if(tail==tail->next)
				tail=NULL;
			else{
				while(temp->next!=tail)
					temp=temp->next;
				temp->next=tail->next;
				tail=temp;
			}
			delete temp2;
			return data;
		}
		else
			return -1;
	}

	bool isEmpty(){
		if(tail==NULL)
			return true;
		else
			return false;
	}

	void traverse(){
		if(tail!=NULL){
			CLLNode *temp=tail->next;
			do{
				visit(temp);
				temp=temp->next;
			}while(temp!=tail->next);
		}
	}

	void visit(CLLNode *p){
		cout<<p->info<<endl;
	}

	void clearAll(){
		head=tail=NULL;
	}
   
};

CLL list,list2;
void reverse(){
	list2.clearAll();
	CLLNode *n=list.tail;
	CLLNode *temp=list.tail;
	n=n->next;
	do{
		list2.addAtHead(n->info);
		n=n->next;
	}while(n!=temp->next);
	list=list2;
}

int main(){
	int choice,info;
	do{
		cout<<"\nCLL MENU\n";
		cout<<"1. Add at tail\n";
		cout<<"2. Add at head\n";
		cout<<"3. Traverse\n";
		cout<<"4. Delete from head\n";
		cout<<"5. Delete from tail\n";
		cout<<"6. Reverse the list\n";
		cout<<"7. Exit\n";
		cout<<"Enter your choice: "; cin>>choice;
		switch(choice){
			case 1 : cout<<"Enter info: "; cin>>info;
					 list.addAtTail(info);
					 break;
			case 2 : cout<<"Enter info: "; cin>>info;
					 list.addAtHead(info);
					 break;
					 break;
			case 3 : list.traverse();
					 break;
			case 4 : info=list.deleteFromHead();
					 if(info!=-1)
					 	cout<<info<<" deleted..\n";
					 else
					 	cout<<"List is empty\n";
					 break;
			case 5 : info=list.deleteFromTail();
					 if(info!=-1)
					 	cout<<info<<" deleted..\n";
					 else
					 	cout<<"List is empty\n";
					 break;
			case 6:  cout<<"Reversed list\n";
					 //list.rev();
					 reverse();
					 list.traverse();
					break;
			default: if(choice!=7)
						 cout<<"INVALID CHOICE!!\n";
		}
	}while(choice!=7);
	return 0;
}