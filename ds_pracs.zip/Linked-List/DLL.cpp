#include <iostream>

using namespace std;

class DLLNode{
public:
	int info;
	DLLNode *prev;
	DLLNode *next;

	DLLNode(){
		info=0;
		prev=next=NULL;
	}
};

class DLL{
	DLLNode *head;
	DLLNode *tail;
public:
	DLL(){
		head=tail=NULL;
	}

	void addAtTail(int data){
		DLLNode *p=new DLLNode;
		p->info=data;
		p->prev=NULL;
		p->next=NULL;
		if(head==NULL)
			head=tail=p;
		else {
			tail->next=p;
			p->prev=tail;
			tail=p;
		}
	}

	void addAtHead(int data){
		DLLNode *p=new DLLNode;
		p->info=data;
		p->prev=NULL;
		p->next=NULL;
		if(head==NULL)
			head=tail=p;
		else{
			p->next=head;
			head->prev=p;
			head=p;
		}
	}

	void traverse(){
		if(head==NULL)
			cout<<"List is empty\n";
		else{
			DLLNode *temp=new DLLNode;
			temp=head;
			while(temp!=NULL){
				visit(temp);
				temp=temp->next;
			}
		}
	}

	void visit(DLLNode *temp){
		cout<<temp->info<<endl;
	}


	/* Function to reverse a Doubly Linked List */
	void reverse(DLLNode **head_ref) 
	{ 
	    DLLNode *temp = NULL;   
	    DLLNode *current = *head_ref; 
	      
	    /* swap next and prev for all nodes of  
	      doubly linked list */
	    while (current !=  NULL) 
	    { 
	    	temp = current->prev; 
	    	current->prev = current->next; 
	        current->next = temp;               
	        current = current->prev; 
	    }       
	      
	    /* Before changing head, check for the cases like empty  
	       list and list with only one node */
	    if(temp != NULL ) 
	       *head_ref = temp->prev; 
	}

	void reverseList(){
		reverse(&head);
	}

	bool deleteFromHead(){
		if(head!=NULL){
			DLLNode *temp=head;
			if(head==tail)
				head=tail=NULL;
			else{
				head=head->next;
				head->prev=NULL;
			}
			visit(temp);
			cout<<"deleted..\n";
			delete temp;
			return true;
		}
		else
			return false;
	}

	bool deleteFromTail(){
		if(head!=NULL){
			DLLNode *temp=tail;
			if(head==tail)
				head=tail=NULL;
			else{
				tail=tail->prev;
				tail->next=NULL;
			}
			visit(temp);
			cout<<" deleted ..\n";
			delete temp;
			return true;
		}
		else
			return false;
	}

};

int main(int argc, char const *argv[])
{
	DLL list;
	int choice,data;
	do{
		cout<<"\nDLL MENU\n";
		cout<<"1. Display\n";
		cout<<"2. Add at tail\n";
		cout<<"3, Add at head\n";
		cout<<"4. Reverse list\n";
		cout<<"5. Delete from head\n";
		cout<<"6. Delete from tail\n";
		cout<<"7. Exit\n";
		cout<<"Enter your choice: "; cin>>choice;
		switch(choice){
			case 1: list.traverse();
					break;		
			case 2: cout<<"Enter element: "; cin>>data;
					list.addAtTail(data);
					break;
			case 3: cout<<"Enter element: "; cin>>data;
					list.addAtHead(data);
					break;
			case 4: list.reverseList();
					cout<<"Reversed list\n";
					list.traverse();
					break;
			case 5: if(!list.deleteFromHead())
						cout<<"List is empty\n";
					break;
			case 6: if(!list.deleteFromTail())
						cout<<"List is empty\n";
					break;
			default: if(choice!=7)
						cout<<"INVALID CHOICE!!\n";
		}
	}while(choice!=7);
	return 0;
}