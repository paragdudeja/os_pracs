#include<iostream>
#include "queue_template.h"
#define COUNT 10
using namespace std;

class BSTNode{
public:
	int info;
	BSTNode *left;
	BSTNode *right;
	BSTNode(int i){
		info=i;
		left=right=NULL;
	}
};

class BST{
private:
	BSTNode *root;
public:
	BST(){
		root=NULL;
	}

	void insert(int data){
		BSTNode *p=new BSTNode(data);
		if(root==NULL){
			root=p;
		}
		else{
			BSTNode *temp=root;
			while(true){
				if(data<temp->info){
					if(temp->left==NULL){
						temp->left=p;
						break;
					}
					else
						temp=temp->left;
				}
				else{
					if(temp->right==NULL){
						temp->right=p;
						break;
					}
					else
						temp=temp->right;
				}
			}
		}
	}

	void visit(BSTNode *p){
		cout<<p->info<<endl;
	}

	void inOrder(BSTNode *temp){
		if(temp!=NULL){
			inOrder(temp->left);
			visit(temp);
			inOrder(temp->right);
		}
	}

	void preOrder(BSTNode *temp){
		if(temp!=NULL){
			visit(temp);
			preOrder(temp->left);
			preOrder(temp->right);
		}
	}

	void postOrder(BSTNode *temp){
		if(temp!=NULL){
			postOrder(temp->left);
			postOrder(temp->right);
			visit(temp);
		}
	}

	void inOrderTraversal(){
		inOrder(root);
	}

	void preOrderTraversal(){
		preOrder(root);
	}

	void postOrderTraversal(){
		postOrder(root);
	}

	void print2DUtil(BSTNode *root, int space) 
	{ 
	    if (root == NULL) 
	        return; 

	    space += COUNT; 

	    print2DUtil(root->right, space); 
	  

	    cout<<endl; 
	    for (int i = COUNT; i < space; i++) 
	        cout<<' '; 
	    cout<<root->info<<endl;
	  
	    print2DUtil(root->left, space); 
	} 

	void print2D() 
	{ 
	   print2DUtil(root, 0); 
	}

	BSTNode* search(int data){
		BSTNode *temp=root;
		while(temp!=NULL){
			if(temp->info==data)
				return temp;
			else if(data<temp->info)
				temp=temp->left;
			else
				temp=temp->right;
		}
		return NULL;
	}

	void deleteByMerging(BSTNode *&node){
		BSTNode *temp=node;
		if(node!=NULL){
			if(!node->right)
				node=node->left;
			else if(node->left==NULL)
				node=node->right;
			else{
				temp=node->left;
				while(temp->right!=NULL)
					temp=temp->right;
				temp->right=node->right;
				temp=node;
				node=node->left;
			}
			delete temp;
		}
	}

	void findAndDeleteByMerging(int data){
		BSTNode *node=root, *prev=NULL;
		while(node!=NULL){
			if(node->info==data)
				break;
			prev=node;
			if(node->info>data)
				node=node->left;
			else
				node=node->right;
		}
		if(node!=NULL&&node->info==data)
			if(node==root)
				deleteByMerging(root);
			else if(prev->left==node)
				deleteByMerging(prev->left);
			else
				deleteByMerging(prev->right);
		else if(root!=NULL)
			cout<<"Element "<<data<<" is not in the tree\n";
		else
			cout<<"The tree is empty\n";
	}

	void deleteByCopying(BSTNode *&node){
		BSTNode *temp=node, *prev;
		if(node->right==NULL)
			node=node->left;
		else if(node->left==NULL)
			node=node->right;
		else{
			temp=node->left;
			prev=node;
			while(temp->right!=NULL){
				prev=temp;
				temp=temp->right;
			}
			node->info=temp->info;
			if(prev==node)
				prev->left=node->left;
			else
				prev->right=temp->left;
		}
		delete temp;
	}

	void findAndDeleteByCopying(int data){
		BSTNode *node=root, *prev=NULL;
		while(node!=NULL){
			if(node->info==data)
				break;
			prev=node;
			if(node->info>data)
				node=node->left;
			else
				node=node->right;
		}
		if(node!=NULL&&node->info==data)
			if(node==root)
				deleteByCopying(root);
			else if(prev->left==node)
				deleteByCopying(prev->left);
			else
				deleteByCopying(prev->right);
		else if(root!=NULL)
			cout<<"Element "<<data<<" is not in the tree\n";
		else
			cout<<"The tree is empty\n";
	}

	/* Function to get the count of leaf nodes in a binary tree*/
	int getLeafCount(BSTNode* temp) { 
	  if(temp == NULL)        
	    return 0; 
	  if(temp->left == NULL && temp->right==NULL)       
	    return 1;             
	  else 
	    return getLeafCount(temp->left)+ 
	           getLeafCount(temp->right);       
	}

	int leafCount(){
		return getLeafCount(root);
	}

	/* Computes the number of non-leaf nodes in a tree. */
	int countNonleaf(BSTNode* temp) { 
	    // Base cases. 
	    if (temp == NULL || (temp->left == NULL &&  
	                         temp->right == NULL)) 
	        return 0; 
	  
	    // If root is Not NULL and its one of its 
	    // child is also not NULL 
	    return 1 + countNonleaf(temp->left) +  
	               countNonleaf(temp->right); 
	}

	int nonLeaf(){
		return countNonleaf(root);
	}

	int maxDepth(BSTNode *temp) { 
	   if (temp==NULL)  
	       return 0; 
	   else 
	   { 
	       /* compute the depth of each subtree */
	       int lDepth = maxDepth(temp->left); 
	       int rDepth = maxDepth(temp->right); 
	  
	       /* use the larger one */
	       if (lDepth > rDepth)  
	           return(lDepth+1); 
	       else return(rDepth+1); 
	   } 
	}

	int getHeight(){
		return maxDepth(root);
	}

	void mirror(BSTNode* node)  
	{ 
		if (node==NULL)  
	    	return;   
	  	else{ 
	    	BSTNode *temp; 
	      
	    	/* do the subtrees */
	    	mirror(node->left); 
	    	mirror(node->right); 
	  
	    	/* swap the pointers in this node */
	    	temp        = node->left; 
	    	node->left  = node->right; 
	    	node->right = temp; 
	  	} 
	}

	void mirrorImage(){
		mirror(root);
	}

	void breadthFirst(){
		Queue<BSTNode*> queue;
		BSTNode *p=root;
		if(p!=NULL){
			queue.enqueue(p);
			while(!queue.isEmpty()){
				p=queue.dequeue();
				visit(p);
				if(p->left)
					queue.enqueue(p->left);
				if(p->right)
					queue.enqueue(p->right);
			}
		}
	}
};

int main(int argc, char const *argv[])
{
	BST bst;
	int data,choice;
	cout<<"BST MENU\n";
	cout<<"1.  Insert\n";
	cout<<"2.  Inorder traversal\n";
	cout<<"3.  Preorder traversal\n";
	cout<<"4.  Postorder traversal\n";
	cout<<"5.  Print 2D\n";
	cout<<"6.  Search\n";
	cout<<"7.  Deletion by merging\n";
	cout<<"8.  Deletion by copyong\n";
	cout<<"9.  Count the non-leaf nodes and leaf nodes\n";
	cout<<"10. Height of binary tree\n";
	cout<<"11. Mirror Image\n";
	cout<<"12. Breadth first traversal\n";
	cout<<"13. Exit\n";
	do{
		cout<<"\nEnter your choice: "; cin>>choice;
		switch(choice){
			case 1: cout<<"Enter data: "; cin>>data;
					bst.insert(data);
					break;
			case 2: bst.inOrderTraversal();
					break;
			case 3: bst.preOrderTraversal();
					break;
			case 4: bst.postOrderTraversal();
					break;
			case 5: bst.print2D();
					break;
			case 6: cout<<"Enter element to search: "; cin>>data;
					if(bst.search(data)!=NULL)
						cout<<"Found :)\n";
					else
						cout<<"Not Found :(\n";
					break;
			case 7: cout<<"Enter the element you want to delete: "; cin>>data;
					bst.findAndDeleteByMerging(data);
					break;
			case 8: cout<<"Enter the element you want to delete: "; cin>>data;
					bst.findAndDeleteByCopying(data);
					break;
			case 9: cout<<"No. of non leaf nodes: "<<bst.nonLeaf()<<endl;
					cout<<"No. of leaf nodes: "<<bst.leafCount()<<endl;
					break;
			case 10:cout<<"Height of binary tree: "<<bst.getHeight()<<endl;
					break;
			case 11:bst.mirrorImage();
					bst.print2D();
					bst.mirrorImage();
					break;
			case 12:bst.breadthFirst();
					break;
			default:if(choice!=13)
						cout<<"INVALID CHOICE!!\n";
		}
	}while(choice!=13);
	return 0;
}