#include<iostream>
using namespace std;

class LowerTriangular{
    int *ar;
    int n;
public:
    LowerTriangular(int size){
        int temp=(size*(size+1))/2;
        ar=new int[temp];
        n=size;
    }

    void store(int i,int j,int data){
        int k=(i*(i+1))/2+j;
        *(ar+k)=data;
    }

    int retrieve(int i,int j){
         if(j>i)
            return 0;
        else{
            int k=(i*(i+1))/2+j;
            return *(ar+k);
        }
    }

    void display(){
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++)
                cout<<retrieve(i,j)<<' ';
            cout<<endl;
        }
    }
};

int main(){
    int row,i,j,el,choice,n;
    cout<<"Enter the number of rows/cloumns in square matrix: "; cin>>row;
    LowerTriangular lt(row);
    n=row;
    do{
        cout<<"\nMAIN MENU\n";
        cout<<"1. Store\n";
        cout<<"2. Retrieve\n";
        cout<<"3. Display matrix\n";
        cout<<"4. Exit\n";
        cout<<"Enter your choice: "; cin>>choice;
        switch(choice){
            case 1: cout<<"Enter row: "; cin>>i;
                    cout<<"Enter column: "; cin>>j;
                    if(i<0||i>=n||j<0||j>=n)
                        cout<<"Index out of bounds\n";
                    else{
                        cout<<"Enter element: "; cin>>el;
                        if(j>i&&el!=0)
                            cout<<"Invalid index to store non zero elemet!!\n";
                        else
                            lt.store(i,j,el);
                    }
                    break;
            case 2: cout<<"Enter row: "; cin>>i;
                    cout<<"Enter column: "; cin>>j;
                    if(i<0||i>=n||j<0||j>=n)
                        cout<<"Index out of bounds\n";
                    else
                        cout<<lt.retrieve(i,j)<<endl;
                    break;
            case 3: lt.display();
                    break;
            default:if(choice!=4)
                        cout<<"Invalid choice!!\n";
        }
    }while(choice!=4);
    return 0;
}