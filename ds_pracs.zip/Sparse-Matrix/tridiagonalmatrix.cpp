#include<iostream>
using namespace std;

class TriDiagonal{
    int *ar;
    int n;
public:
    TriDiagonal(int size){
        ar=new int[3*size-2];
        n=size;
    }

    void store(int i,int j,int data){
        int k=2*i+j;
        *(ar+k)=data;
    }

    int retrieve(int i,int j){
        if(i==j||i-j==1||j-i==1){
            int k=2*i+j;
            return *(ar+k);
        }
        else
            return 0;
    }

    void display(){
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++)
                cout<<retrieve(i,j)<<' ';
            cout<<endl;
        }
    }
};

int main(){
    int n,i,j,el,choice;
    cout<<"Enter the number of rows/columns in square matrix: "; cin>>n;
    TriDiagonal td(n);
    cout<<"\nMAIN MENU\n";
    cout<<"1. Store\n";
    cout<<"2. Retrieve\n";
    cout<<"3. Display matrix\n";
    cout<<"4. Exit\n";
    do{
        cout<<"\nEnter your choice: "; cin>>choice;
        switch(choice){
            case 1: cout<<"Enter row: "; cin>>i;
                    cout<<"Enter column: "; cin>>j;
                    if(i<0||i>=n||j<0||j>=n)
                        cout<<"Index out of bounds\n";
                    else{
                        cout<<"Enter element: "; cin>>el;
                        if(i==j||i-j==1||j-i==1||el==0)
                            td.store(i,j,el);
                        else
                            cout<<"Invalid index to store non zero elemet!!\n";
                    }
                    break;
            case 2: cout<<"Enter row: "; cin>>i;
                    cout<<"Enter column: "; cin>>j;
                    if(i<0||i>=n||j<0||j>=n)
                        cout<<"Index out of bounds\n";
                    else
                        cout<<"Element is: "<<td.retrieve(i,j)<<endl;
                    break;
            case 3: td.display();
                    break;
            default:if(choice!=4)
                        cout<<"Invalid choice!!\n";
        }
    }while(choice!=4);
    return 0;
}