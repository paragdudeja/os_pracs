package com.tutorialsduniya;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.DriverManager;
import java.sql.*;
import java.util.Scanner;

public static void main(String[] args)
{
    ResultSet rs;
    try
    {
        int c1=0;
        int c2=0;
        int c3=0;
        int c4=0;
        Class.forName("com.mysql.jdbc.Driver");
        Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/ak","root","12345");
        Statement stmt= con.createStatement();
        do{
            System.out.println("MENU");
            System.out.println("1.FIND TOTAL STUDENTS");
            System.out.println("2.Each subject avergae marks");
            System.out.println("3.STUDENT NAME WITH HIGHEST MARKS");
            System.out.println("4.NO OF STUDENTS GETTING FIRST SECOND AND THIRD DIVISION");
            System.out.println("5.SUBJECT WISE TOPEERS");
            System.out.println("6.AVERGAE MARKS");
            System.out.println("7.STUDENT GETTING SECOND HIGHEST MARKS");

			int ch;
            String sub;
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            Scanner sc = new Scanner(System.in);
            ch=sc.nextInt();

			switch(ch)
            {
                case 1: rs= stmt.executeQuery("select count(*) total from student");
                        rs.next();
                        int tota =rs.getInt("total");
                        System.out.println(tota);
                        break;

				case 2: System.out.println("Enter the subject");
                        sub=sc.next();
                        String sql="select AVG(marks) as abg from result where subject='"+sub+"'";
                        rs=stmt.executeQuery(sql);
                        rs.next();
                        int s=rs.getInt("abg");
                        System.out.println(s);
						break;

               case 3: System.out.println("");
                        rs = stmt.executeQuery("Select max(marks),s.name as name from student s,result r where s.rollno=r.rollno");
                        rs.next();
                        String n=rs.getString("name");
                        System.out.println("The student with highest marks is "+" "+n);
						break;

               case 4: rs=stmt.executeQuery("select rollno,(SUM(marks)/300)*100 AS 'DIV' from result GROUP BY rollno");
	                    while(rs.next())
    	                {
        	                if(rs.getInt("div")>90)
            	            {
                	            c1++;
                    	    }
							else if(rs.getInt("div")<90&&rs.getInt("div")>60)
							{
								c2++;
							}
							else if(rs.getInt("div")<60&&rs.getInt("div")>33)
							{
								c3++;
							}
							else
							{
								c4++;
							}
						}
                        System.out.println(+c1);
                        System.out.println(+c2);
                        System.out.println(+c3);
                        System.out.println(+c4);
						break;

				case 5: rs=stmt.executeQuery("select s.name as 'name',r.subject as 'sub',max(r.marks) from student s,result r where r.rollno=s.rollno group by subject");
                        while(rs.next())
                        {
                            System.out.println("max marks in "+rs.getString("sub")+"is of "+rs.getString("name"));
                        }
                        break;

				case 6: rs=stmt.executeQuery("select s.name as 'name',avg(r.marks) as 'avg' from student s, result r where s.rollno=r.rollno group by r.rollno");
                        while(rs.next())
                        {
                            System.out.println("Average marks of "+rs.getString("name")+"are"+rs.getInt("avg"));
						}
						break;

                case 7: rs=stmt.executeQuery("SELECT S.NAME,SUM(R.MARKS)) AS 'TOTA' FROM STUDENT S RESULT R WHERE R.ROLLNO=S.ROLLNO GROUP BY R.ROLLNO ORDER BY TOTA ");
                        System.out.println(" second topeer"+rs.getString("name"));
                        break;
			}
	
			System.out.println("Do u want to continue y\n");
            String s= br.readLine();
            if(s.startsWith("n"))
            {
                System.exit(0);
            }
        } while(true);
    }
    catch(Exception e)
    {
        System.out.println(e);
        // TODO code application logic here
    }
}