import java.io.PrintStream;
import java.util.Scanner;
class main1
{
	public static void main(String[] paramArrayOfString)
	{
		Scanner localScanner = new Scanner(System.in);
		System.out.println("Enter");
		System.out.println("1.staticStack");
		System.out.println("2.dynamicStack");
		System.out.println("3.Exit");
		int m = localScanner.nextInt();
	
		switch (m)
		{
			case 1: System.out.println("Enter array size");
				int i3 = localScanner.nextInt();
				staticStack localstaticStack = new staticStack(i3);
				System.out.println("Enter");
				System.out.println("1.Push");
				System.out.println("2.Pop");
				System.out.println("3.Display");
				int i4;
				do{
					System.out.println("Enter your choice");
					int i = localScanner.nextInt();

					switch (i)
					{
						case 1: System.out.println("Enter a number to be pushed into the stack");
								int j = localScanner.nextInt();
								localstaticStack.push(j);
								break;

						case 2: int k = localstaticStack.pop();
								if (k == -1)
								{
									System.out.println("Underflow");
								}
								else
								{
									System.out.println("Number popped =" + k);
								}
								break;
						case 3: localstaticStack.display();
					}

					System.out.println("Enter 0 if you want to continue");
					i4 = localScanner.nextInt();
				} while (i4 == 0);
				break;
		
			case 2: dynamicStack localdynamicStack = new dynamicStack();
				System.out.println("Enter");
				System.out.println("1.Push");
				System.out.println("2.Pop");
				System.out.println("3.Display");

				for (;;)
				{
				System.out.println("Enter your choice");
				int n = localScanner.nextInt();

				switch (n)
				{
					case 1: System.out.println("Enter a number to be pushed into the stack");
							int i1 = localScanner.nextInt();
							localdynamicStack.push(i1);
							break;
					case 2: int i2 = localdynamicStack.pop();
							if (i2 == -1)
							{
								System.out.println("Underflow");
							}
							else
							{
								System.out.println("Number popped =" + i2);
							}
							break;
					case 3: localdynamicStack.display();
				}

				System.out.println("Enter 0 if you want to continue");
				int i5 = localScanner.nextInt();
				if (i5 != 0)
				{
					break;
				}
			}
		}
	}
}