import java.io.PrintStream;
import java.util.ArrayList;

class dynamicStack extends Stack
{
	ArrayList<Integer> arr;
	dynamicStack()
	{
		this.arr = new ArrayList();
	}

	void push(int paramInt)
	{
		this.arr.add(++this.top, Integer.valueOf(paramInt));
	}

	int pop()
	{
		if (this.top == -1)
		{
		return -1;
		}
		return ((Integer)this.arr.remove(this.top--)).intValue();
	}

	void display()
	{
		System.out.print("The Stack is : ");
		for (int i = 0; i <this.arr.size(); i++)
		{
			System.out.print(this.arr.get(i) + " ");
		}
		System.out.println();
	}
}
