import java.io.PrintStream;

class staticStack extends Stack
{
	int[] arr;
	int size;
	staticStack(int paramInt)
	{
		this.size = paramInt;
		this.arr = new int[this.size];
	}

	void push(int paramInt)
	{
		if (this.top == this.size - 1)
		{
			System.out.println("overflow");
		}
		else
		{
			this.arr[(++this.top)] = paramInt;
		}
	}

	int pop()
	{
		if (this.top == -1)
		{
			return -1;
		}
		return this.arr[(this.top--)];
	}

	void display()
	{
		System.out.print("The Stack is : ");
		for (int i = 0; i <= this.top; i++)
		{
			System.out.print(this.arr[i] + " ");
		}
		System.out.println();
	}
}