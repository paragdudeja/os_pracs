package com.tutorialsduniya;
import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.*;
import java.io.*;
import java.util.*;

public class Program7 extends SimpleTagSupport
{
    String input;
    int start,end;
    public void setInput(String input)
    {
        this.input=input;
    }
    public void setStart(int start)
    {
        this.start=start;
    }
    public void setEnd(int end)
    {
        this.end=end;
    }
    public void doTag() throws IOException
    {
        JspWriter out = getJspContext().getOut();
        if(start>=0 && end<input.length())
        {
            for(int i=start;i<=end;i++)
            {
                out.print(input.charAt(i));
            }
        }
        else 
            out.println("Invalid start or end");
    }
}

 
