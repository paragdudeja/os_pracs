#include <iostream>
using namespace std;

void maxHeapify(int A[],int n,int i){
	int largest=i;
	int l=2*i+1;
	int r=2*i+2;

	if(l<n&&A[l]>A[largest])
		largest=l;

	if(r<n&&A[r]>A[largest])
		largest=r;

	if(largest!=i){
		swap(A[i],A[largest]);
		maxHeapify(A,n,largest);
	}
}	



void heapSort(int A[],int n){
	int i;
	for(i=n/2-1;i>=0;i--)
		maxHeapify(A,n,i);

	for(i=n-1;i>=0;i--){
		swap(A[0],A[i]);
		maxHeapify(A,i,0);
	}
}

void swap(int &x,int &y){
	int temp=x;
	x=y;
	y=temp;
}

void displayArray(int A[],int n){
	for(int i=0;i<n;i++)
		cout<<A[i]<<' ';
	cout<<endl;
}

int main(){
	int A[]={3,6,9,1,2,5,4,8};
	int n=sizeof(A)/sizeof(A[0]);
	cout<<"Original Array: ";
	displayArray(A,n);
//	cout<<"n="<<n<<endl;
	heapSort(A,n);
	cout<<"Sorted array after heap sort: ";
	displayArray(A,n);
}